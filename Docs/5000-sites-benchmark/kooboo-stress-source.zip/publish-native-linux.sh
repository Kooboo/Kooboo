#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

dotnet publish "$script_dir/Kooboo.SiteStressTest.csproj" \
  -c Release \
  -r linux-x64 \
  --self-contained true \
  -p:PublishAot=true \
  -p:StripSymbols=true \
  -o "$script_dir/publish/linux-x64-native"

rm -f "$script_dir/publish/linux-x64-native/kooboo-site-stress"

echo
echo "Native Linux application created in:"
echo "$script_dir/publish/linux-x64-native"
