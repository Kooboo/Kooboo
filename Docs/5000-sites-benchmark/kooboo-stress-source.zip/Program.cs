using System.Globalization;

namespace Kooboo.SiteStressTest;

public static class Program
{
    public static async Task<int> Main(string[] args)
    {
        CommandLineOptions commandLine;

        try
        {
            commandLine = args.Length == 0
                ? CommandLineOptions.ReadInteractive()
                : CommandLineOptions.Parse(args);
        }
        catch (ArgumentException exception)
        {
            Console.Error.WriteLine($"Error: {exception.Message}");
            Console.Error.WriteLine();
            CommandLineOptions.WriteHelp(Console.Error);
            return 1;
        }

        if (commandLine.ShowHelp)
        {
            CommandLineOptions.WriteHelp(Console.Out);
            return 0;
        }

        using var cancellation = new CancellationTokenSource();
        ConsoleCancelEventHandler cancelHandler = (_, eventArgs) =>
        {
            eventArgs.Cancel = true;
            cancellation.Cancel();
            Console.WriteLine("Cancellation requested. Waiting for active requests to stop...");
        };

        Console.CancelKeyPress += cancelHandler;

        try
        {
            string outputDirectory = commandLine.GetOutputDirectory();

            if (commandLine.Mode == TestMode.Sweep)
            {
                var options = new SiteSpeedTestOptions
                {
                    FirstSiteNumber = commandLine.FirstSiteNumber,
                    LastSiteNumber = commandLine.LastSiteNumber,
                    RequestsPerSecond = commandLine.RequestsPerSecond,
                    RequestTimeout = commandLine.RequestTimeout,
                    UrlTemplate = commandLine.UrlTemplate,
                    ExpectedTextTemplate = commandLine.ExpectedTextTemplate,
                    MaxRetryAttempts = commandLine.MaxRetryAttempts,
                    RetryDelay = commandLine.RetryDelay,
                    WriteProgressToConsole = !commandLine.Quiet
                };

                SiteSpeedTestReport report = await SiteSpeedTester.TestAsync(
                    options,
                    cancellation.Token).ConfigureAwait(false);

                Console.WriteLine("Writing detailed result files...");
                await ResultWriter.WriteSweepAsync(
                    report,
                    outputDirectory,
                    cancellation.Token).ConfigureAwait(false);

                Console.WriteLine($"Results written to: {Path.GetFullPath(outputDirectory)}");
                int exitCode = report.FailedCount == 0 ? 0 : 2;
                PauseBeforeExit(commandLine);
                return exitCode;
            }

            var stressOptions = new StressTestOptions
            {
                FirstSiteNumber = commandLine.FirstSiteNumber,
                LastSiteNumber = commandLine.LastSiteNumber,
                RequestsPerSecond = commandLine.RequestsPerSecond,
                Duration = commandLine.Duration,
                RequestTimeout = commandLine.RequestTimeout,
                MaxConcurrency = commandLine.MaxConcurrency,
                UrlTemplate = commandLine.UrlTemplate,
                ExpectedTextTemplate = commandLine.ExpectedTextTemplate,
                SelectionMode = commandLine.SelectionMode,
                RandomSeed = commandLine.RandomSeed,
                WriteProgressToConsole = !commandLine.Quiet
            };

            StressTestReport stressReport = await StressTestRunner.RunAsync(
                stressOptions,
                cancellation.Token).ConfigureAwait(false);

            Console.WriteLine("Writing detailed result files...");
            await ResultWriter.WriteStressAsync(
                stressReport,
                outputDirectory,
                cancellation.Token).ConfigureAwait(false);

            Console.WriteLine($"Results written to: {Path.GetFullPath(outputDirectory)}");
            int stressExitCode = stressReport.FailedCount == 0 ? 0 : 2;
            PauseBeforeExit(commandLine);
            return stressExitCode;
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Test cancelled.");
            PauseBeforeExit(commandLine);
            return 130;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"Fatal error: {exception.Message}");
            PauseBeforeExit(commandLine);
            return 1;
        }
        finally
        {
            Console.CancelKeyPress -= cancelHandler;
        }
    }

    private static void PauseBeforeExit(CommandLineOptions options)
    {
        if (!options.PauseBeforeExit || Console.IsInputRedirected)
        {
            return;
        }

        Console.WriteLine();
        Console.Write("Press any key to exit...");
        Console.ReadKey(intercept: true);
        Console.WriteLine();
    }
}

internal enum TestMode
{
    Sweep,
    Stress
}

internal sealed class CommandLineOptions
{
    private const int MaximumRequestsPerSecond = 200;
    private const int MaximumDurationMinutes = 20;
    private const int MaximumConcurrency = 4096;

    public bool ShowHelp { get; private set; }

    public TestMode Mode { get; private set; } = TestMode.Stress;

    public int FirstSiteNumber { get; private set; } = 1;

    public int LastSiteNumber { get; private set; } = 5000;

    public int RequestsPerSecond { get; private set; } = 10;

    public TimeSpan Duration { get; private set; } = TimeSpan.FromMinutes(5);

    public TimeSpan RequestTimeout { get; private set; } = TimeSpan.FromSeconds(30);

    public int MaxConcurrency { get; private set; } = 200;

    public string UrlTemplate { get; private set; } = "https://site{0}.trykooboo.com/";

    public string? ExpectedTextTemplate { get; private set; }

    public SiteSelectionMode SelectionMode { get; private set; } = SiteSelectionMode.Sequential;

    public int RandomSeed { get; private set; } = 1942;

    public int MaxRetryAttempts { get; private set; } = 1;

    public TimeSpan RetryDelay { get; private set; } = TimeSpan.FromSeconds(2);

    public string? OutputDirectory { get; private set; }

    public bool Quiet { get; private set; }

    public bool PauseBeforeExit { get; private set; }

    public static CommandLineOptions Parse(string[] args)
    {
        var options = new CommandLineOptions();

        for (int index = 0; index < args.Length; index++)
        {
            string argument = args[index];
            switch (argument)
            {
                case "--help":
                case "-h":
                    options.ShowHelp = true;
                    break;
                case "--mode":
                    options.Mode = ParseMode(GetValue(args, ref index, argument));
                    break;
                case "--sites":
                    options.LastSiteNumber = ParsePositiveInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--first-site":
                    options.FirstSiteNumber = ParsePositiveInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--last-site":
                    options.LastSiteNumber = ParsePositiveInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--rps":
                    options.RequestsPerSecond = ParsePositiveInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--duration":
                    options.Duration = ParseDuration(GetValue(args, ref index, argument), argument);
                    break;
                case "--timeout":
                    options.RequestTimeout = ParseDuration(GetValue(args, ref index, argument), argument);
                    break;
                case "--max-concurrency":
                    options.MaxConcurrency = ParsePositiveInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--url-template":
                    options.UrlTemplate = GetValue(args, ref index, argument);
                    break;
                case "--expect":
                    options.ExpectedTextTemplate = GetValue(args, ref index, argument);
                    break;
                case "--selection":
                    options.SelectionMode = ParseSelectionMode(GetValue(args, ref index, argument));
                    break;
                case "--seed":
                    options.RandomSeed = ParseInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--retries":
                    options.MaxRetryAttempts = ParseNonNegativeInt(GetValue(args, ref index, argument), argument);
                    break;
                case "--retry-delay":
                    options.RetryDelay = ParseNonNegativeDuration(GetValue(args, ref index, argument), argument);
                    break;
                case "--output":
                    options.OutputDirectory = GetValue(args, ref index, argument);
                    break;
                case "--quiet":
                    options.Quiet = true;
                    break;
                default:
                    throw new ArgumentException($"Unknown argument '{argument}'.");
            }
        }

        options.Validate();
        return options;
    }

    public static CommandLineOptions ReadInteractive()
    {
        Console.WriteLine("Kooboo site stress test");
        Console.WriteLine("Only test systems you own or have permission to test.");
        Console.WriteLine("Press Ctrl+C at any time to stop.");
        Console.WriteLine();

        Console.WriteLine("Test target:");
        Console.WriteLine("  1 - Multiple domains (site1 through site5000)");
        Console.WriteLine("  2 - Single domain (site1942 only)");
        int targetChoice = ReadInteger(
            "Choose 1 or 2: ",
            minimum: 1,
            maximum: 2);
        bool useSingleDomain = targetChoice == 2;

        int requestsPerSecond = ReadInteger(
            "Requests per second (1-200): ",
            minimum: 1,
            maximum: MaximumRequestsPerSecond);
        int durationMinutes = ReadInteger(
            "Test duration in minutes (1-20): ",
            minimum: 1,
            maximum: MaximumDurationMinutes);

        return new CommandLineOptions
        {
            Mode = TestMode.Stress,
            FirstSiteNumber = useSingleDomain ? 1942 : 1,
            LastSiteNumber = useSingleDomain ? 1942 : 5000,
            RequestsPerSecond = requestsPerSecond,
            Duration = TimeSpan.FromMinutes(durationMinutes),
            MaxConcurrency = GetRecommendedMaxConcurrency(requestsPerSecond),
            ExpectedTextTemplate = "Site {0}",
            SelectionMode = SiteSelectionMode.Sequential,
            Quiet = false,
            PauseBeforeExit = true
        };
    }

    public string GetOutputDirectory()
    {
        if (!string.IsNullOrWhiteSpace(OutputDirectory))
        {
            return OutputDirectory;
        }

        string timestamp = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
        return Path.Combine("results", timestamp);
    }

    public static void WriteHelp(TextWriter writer)
    {
        writer.WriteLine("Kooboo site sweep and stress-test client");
        writer.WriteLine("Only test systems you own or have permission to test.");
        writer.WriteLine();
        writer.WriteLine("Run without arguments for a guided stress test.");
        writer.WriteLine("Choose multiple domains or one domain, then enter rate and duration.");
        writer.WriteLine("Guided mode verifies that each response contains \"Site {0}\".");
        writer.WriteLine();
        writer.WriteLine("Examples:");
        writer.WriteLine("  kooboo-stress");
        writer.WriteLine("  kooboo-stress --mode sweep --sites 5000 --rps 10");
        writer.WriteLine("  kooboo-stress --mode stress --sites 5000 --rps 50 --duration 5m");
        writer.WriteLine("  kooboo-stress --mode stress --rps 100 --duration 10m --selection random");
        writer.WriteLine("  kooboo-stress --mode stress --expect \"site{0}\" --output ./results/demo");
        writer.WriteLine();
        writer.WriteLine("Options:");
        writer.WriteLine("  --mode sweep|stress       Test every site once, or send traffic for a duration.");
        writer.WriteLine("  --sites N                 Shorthand for --last-site N. Default: 5000.");
        writer.WriteLine("  --first-site N            First numbered site. Default: 1.");
        writer.WriteLine("  --last-site N             Last numbered site. Default: 5000.");
        writer.WriteLine("  --rps N                   Target starts/second, 1-200. Default: 10.");
        writer.WriteLine("  --duration 30s|5m         Stress duration, maximum 20m. Default: 5m.");
        writer.WriteLine("  --timeout 30s             Per-request timeout. Default: 30s.");
        writer.WriteLine("  --max-concurrency N       Maximum active requests, 1-4096. Default: 200.");
        writer.WriteLine("  --selection sequential|random   Site selection in stress mode.");
        writer.WriteLine("  --seed N                  Repeatable random-selection seed. Default: 1942.");
        writer.WriteLine("  --url-template TEXT       URL containing {0} for the site number.");
        writer.WriteLine("  --expect TEXT             Optional body text containing {0} to verify per site.");
        writer.WriteLine("  --retries N               Sweep-only retry count. Default: 1.");
        writer.WriteLine("  --retry-delay 2s          Delay before sweep retries. Default: 2s.");
        writer.WriteLine("  --output DIRECTORY        Result directory. Default: ./results/<UTC timestamp>.");
        writer.WriteLine("  --quiet                   Disable one-second console progress.");
        writer.WriteLine("  --help                    Show this help.");
    }

    private void Validate()
    {
        if (LastSiteNumber < FirstSiteNumber)
        {
            throw new ArgumentException("--last-site must be greater than or equal to --first-site.");
        }

        if (!UrlTemplate.Contains("{0}", StringComparison.Ordinal))
        {
            throw new ArgumentException("--url-template must contain the {0} site-number placeholder.");
        }

        if (ExpectedTextTemplate is not null
            && !ExpectedTextTemplate.Contains("{0}", StringComparison.Ordinal))
        {
            throw new ArgumentException("--expect must contain the {0} site-number placeholder.");
        }

        if (RequestsPerSecond > MaximumRequestsPerSecond)
        {
            throw new ArgumentException($"--rps must be between 1 and {MaximumRequestsPerSecond}.");
        }

        if (Mode == TestMode.Stress && Duration > TimeSpan.FromMinutes(MaximumDurationMinutes))
        {
            throw new ArgumentException(
                $"--duration cannot be longer than {MaximumDurationMinutes} minutes in stress mode.");
        }

        if (MaxConcurrency > MaximumConcurrency)
        {
            throw new ArgumentException(
                $"--max-concurrency must be between 1 and {MaximumConcurrency}.");
        }

        long plannedRequests = (long)Math.Ceiling(Duration.TotalSeconds * RequestsPerSecond);
        if (Mode == TestMode.Stress && plannedRequests > 5_000_000)
        {
            throw new ArgumentException(
                "The requested stress run exceeds 5,000,000 requests. Reduce --duration or --rps.");
        }
    }

    private static string GetValue(string[] args, ref int index, string argument)
    {
        if (++index >= args.Length)
        {
            throw new ArgumentException($"Missing value after {argument}.");
        }

        return args[index];
    }

    private static int ReadInteger(string prompt, int minimum, int maximum)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();

            if (input is null)
            {
                throw new ArgumentException("Console input ended before the test settings were entered.");
            }

            if (int.TryParse(
                    input.Trim(),
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out int value)
                && value >= minimum
                && value <= maximum)
            {
                return value;
            }

            Console.WriteLine($"Please enter a whole number from {minimum} to {maximum}.");
        }
    }

    private static int GetRecommendedMaxConcurrency(int requestsPerSecond)
    {
        return Math.Clamp(requestsPerSecond * 2, 200, 512);
    }

    private static TestMode ParseMode(string value)
    {
        return value.ToLowerInvariant() switch
        {
            "sweep" => TestMode.Sweep,
            "stress" => TestMode.Stress,
            _ => throw new ArgumentException("--mode must be 'sweep' or 'stress'.")
        };
    }

    private static SiteSelectionMode ParseSelectionMode(string value)
    {
        return value.ToLowerInvariant() switch
        {
            "sequential" => SiteSelectionMode.Sequential,
            "random" => SiteSelectionMode.Random,
            _ => throw new ArgumentException("--selection must be 'sequential' or 'random'.")
        };
    }

    private static int ParsePositiveInt(string value, string argument)
    {
        int result = ParseInt(value, argument);
        return result > 0
            ? result
            : throw new ArgumentException($"{argument} must be greater than zero.");
    }

    private static int ParseNonNegativeInt(string value, string argument)
    {
        int result = ParseInt(value, argument);
        return result >= 0
            ? result
            : throw new ArgumentException($"{argument} cannot be negative.");
    }

    private static int ParseInt(string value, string argument)
    {
        return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int result)
            ? result
            : throw new ArgumentException($"{argument} requires an integer value.");
    }

    private static TimeSpan ParseDuration(string value, string argument)
    {
        TimeSpan result = ParseNonNegativeDuration(value, argument);
        return result > TimeSpan.Zero
            ? result
            : throw new ArgumentException($"{argument} must be greater than zero.");
    }

    private static TimeSpan ParseNonNegativeDuration(string value, string argument)
    {
        if (TimeSpan.TryParse(value, CultureInfo.InvariantCulture, out TimeSpan timeSpan)
            && timeSpan >= TimeSpan.Zero)
        {
            return timeSpan;
        }

        if (value.Length < 2
            || !double.TryParse(
                value.AsSpan(0, value.Length - 1),
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out double amount)
            || amount < 0)
        {
            throw new ArgumentException($"{argument} requires a duration such as 30s, 5m, or 1h.");
        }

        return char.ToLowerInvariant(value[^1]) switch
        {
            's' => TimeSpan.FromSeconds(amount),
            'm' => TimeSpan.FromMinutes(amount),
            'h' => TimeSpan.FromHours(amount),
            _ => throw new ArgumentException($"{argument} requires a duration such as 30s, 5m, or 1h.")
        };
    }
}
