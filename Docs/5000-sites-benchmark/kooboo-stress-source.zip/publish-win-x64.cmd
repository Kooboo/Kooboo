@echo off
setlocal

dotnet publish "%~dp0Kooboo.SiteStressTest.csproj" ^
  -c Release ^
  -r win-x64 ^
  --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:PublishTrimmed=true ^
  -p:DebugType=None ^
  -p:DebugSymbols=false ^
  -o "%~dp0publish\win-x64"

if errorlevel 1 exit /b %errorlevel%

echo.
echo Windows application created in:
echo %~dp0publish\win-x64
