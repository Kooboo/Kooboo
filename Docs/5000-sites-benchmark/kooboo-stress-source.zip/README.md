# Kooboo site stress test

Standalone, dependency-free command-line client for testing numbered Kooboo sites from a Linux machine near the server.

Only run load tests against systems you own or have explicit permission to test.
The official binary enforces a 200 requests/second safety cap, but server-side rate
limits are still required because users can run multiple copies or modify the client.

The application has two modes:

- `sweep`: request every site once, then retry failed sites. Use this to prove that all 5,000 site bindings respond.
- `stress`: repeatedly request sites for a fixed duration. Use this to measure pressure, throughput, errors, and latency.

Running the application without arguments starts a guided test. It asks only for:

- Test target: all 5,000 domains or the single domain `site1942.trykooboo.com`
- Requests per second (`1` through `200`)
- Test duration in minutes (`1` through `20`)

## Build a copyable Linux application on Windows

Run:

```cmd
publish-linux-x64.cmd
```

Copy the contents of `publish\linux-x64` to the Linux test server. The output is self-contained, so that server does not need .NET installed.

To create the self-contained Windows x64 application, run:

```cmd
publish-win-x64.cmd
```

The Windows output is written to `publish\win-x64`.

On Linux:

```bash
chmod +x kooboo-stress
./kooboo-stress
```

Then select the target and enter the requested rate and duration. Multiple-domain mode
cycles through `site1.trykooboo.com` to `site5000.trykooboo.com`. Single-domain mode
repeatedly requests `site1942.trykooboo.com` and reuses its connections. Both modes
print a status line every second and write the final summary and CSV details under
`results/<UTC timestamp>`.

Guided mode also verifies that each response contains its own exact marker, such as
`Site 4996` in multiple-domain mode or `Site 1942` in single-domain mode. A response
from the wrong site is reported as a content mismatch even when its HTTP status is 200.

After a guided test finishes, the final result remains visible until you press a key.
Advanced command-line runs exit immediately so they remain suitable for scripts.

Root access is not required. Running it as root works, but a normal user is safer and
is sufficient unless that account has an unusually low open-file limit.

## Advanced command-line use

To verify every site once and retry failures:

```bash
./kooboo-stress --mode sweep --sites 5000 --rps 10
```

For a timed pressure test:

```bash
./kooboo-stress \
  --mode stress \
  --sites 5000 \
  --rps 50 \
  --duration 5m \
  --max-concurrency 200 \
  --selection sequential
```

Increase load progressively instead of jumping directly to a high rate:

```bash
./kooboo-stress --mode stress --sites 5000 --rps 6  --duration 5m
./kooboo-stress --mode stress --sites 5000 --rps 12 --duration 5m
./kooboo-stress --mode stress --sites 5000 --rps 24 --duration 5m
./kooboo-stress --mode stress --sites 5000 --rps 48 --duration 5m
```

The program writes a `summary.txt` and request-level CSV file under `results/<UTC timestamp>` by default.

Both guided and advanced stress tests enforce a maximum of 200 requests per second
and 20 minutes per run.

## Verify that each hostname reaches the correct site

If every cloned site contains its own number somewhere in the HTML, enable content validation:

```bash
./kooboo-stress \
  --mode stress \
  --sites 5000 \
  --rps 24 \
  --duration 10m \
  --expect "site{0}"
```

For example, the response from `site1942.trykooboo.com` must contain `site1942`. A missing marker is recorded as `ContentMismatch`, even when the HTTP status is 200.

## NativeAOT build

The code is AOT-compatible. To create a NativeAOT Linux binary, copy the project source to a Linux build machine with the .NET 10 SDK and C/C++ build prerequisites, then run:

```bash
chmod +x publish-native-linux.sh
./publish-native-linux.sh
```

NativeAOT Linux publishing should be performed on Linux. The Windows publish script creates a trimmed, self-contained single-file Linux application instead.

## Important measurement boundary

This client downloads the complete root HTTP response. It measures DNS/network/TLS/HTTP/server rendering and content transfer, but it does not execute JavaScript or fetch CSS, images, fonts, or other browser-discovered resources.

Stress mode deliberately does not retry requests. Retries would hide errors and change the offered load. Sweep mode retains retries because its purpose is site-by-site verification.

## Using 5,000 copies of one website

Cloning one site 5,000 times is valid for measuring domain routing, per-site metadata/database overhead, site isolation, and the cost of serving one controlled workload. It is not a complete production-capacity workload because identical pages can produce unusually favorable CPU, compression, filesystem-cache, and render-plan-cache behavior.

At minimum, put a unique marker such as `site1942` into each clone and use `--expect "site{0}"`. Without this check, 5,000 HTTP 200 responses could still be the same fallback site or an incorrect binding.

For a stronger demonstration, divide the sites among several workload families and run each important path separately with `--url-template`:

- Lightweight landing page
- Dynamic list and detail pages backed by site data
- Database query or API page
- Image/static-file-heavy page
- JavaScript-rendered or business-application page

Keep one identical-site run as the controlled baseline, then compare it with the mixed workload. Report both instead of treating the cloned-site result as universal production capacity.
