using System.Buffers;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text;

namespace Kooboo.SiteStressTest;

public static class StressTestRunner
{
    private const int ContentBufferSize = 16 * 1024;
    private const int MaximumRequestsPerSecond = 200;
    private const int MaximumConcurrency = 4096;
    private static readonly TimeSpan MaximumDuration = TimeSpan.FromMinutes(20);

    public static async Task<StressTestReport> RunAsync(
        StressTestOptions options,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(options);
        ValidateOptions(options);

        int requestCount = checked((int)Math.Ceiling(
            options.Duration.TotalSeconds * options.RequestsPerSecond));
        var results = new StressRequestResult[requestCount];
        Uri[] siteUris = CreateSiteUris(options);
        byte[][]? expectedBytesBySite = CreateExpectedBytes(options);
        var activeTasks = new List<Task>(options.MaxConcurrency * 2);
        using var concurrency = new SemaphoreSlim(options.MaxConcurrency, options.MaxConcurrency);
        using var client = CreateHttpClient(options);

        StressConsoleReporter? reporter = options.WriteProgressToConsole
            ? new StressConsoleReporter(options, requestCount)
            : null;

        DateTimeOffset startedAtUtc = DateTimeOffset.UtcNow;
        long testStartedTimestamp = Stopwatch.GetTimestamp();
        long startIntervalTicks = Math.Max(1, Stopwatch.Frequency / options.RequestsPerSecond);
        long nextStartTimestamp = testStartedTimestamp;
        var activeRequests = new ActiveRequestCounter();

        try
        {
            for (int requestIndex = 0; requestIndex < requestCount; requestIndex++)
            {
                await WaitForStartSlotAsync(nextStartTimestamp, cancellationToken).ConfigureAwait(false);
                await concurrency.WaitAsync(cancellationToken).ConfigureAwait(false);

                long actualStartTimestamp = Stopwatch.GetTimestamp();
                int siteNumber = SelectSiteNumber(options, requestIndex);
                int siteIndex = siteNumber - options.FirstSiteNumber;

                activeRequests.Increment();
                reporter?.ReportRequestStarted();

                activeTasks.Add(RunRequestAndStoreAsync(
                    client,
                    concurrency,
                    siteUris[siteIndex],
                    expectedBytesBySite?[siteIndex],
                    siteNumber,
                    requestIndex + 1,
                    results,
                    requestIndex,
                    reporter,
                    activeRequests,
                    cancellationToken));

                if (activeTasks.Count >= options.MaxConcurrency * 2)
                {
                    activeTasks.RemoveAll(static task => task.IsCompleted);
                }

                long scheduledNextTimestamp = nextStartTimestamp + startIntervalTicks;
                nextStartTimestamp = scheduledNextTimestamp > actualStartTimestamp
                    ? scheduledNextTimestamp
                    : actualStartTimestamp + startIntervalTicks;
            }
        }
        catch
        {
            client.CancelPendingRequests();
            await ObserveScheduledTasksAsync(activeTasks).ConfigureAwait(false);
            if (reporter is not null)
            {
                await reporter.StopAsync().ConfigureAwait(false);
            }

            throw;
        }

        TimeSpan dispatchElapsed = Stopwatch.GetElapsedTime(testStartedTimestamp);

        try
        {
            await Task.WhenAll(activeTasks).ConfigureAwait(false);
        }
        catch
        {
            client.CancelPendingRequests();
            if (reporter is not null)
            {
                await reporter.StopAsync().ConfigureAwait(false);
            }

            throw;
        }

        TimeSpan totalElapsed = Stopwatch.GetElapsedTime(testStartedTimestamp);
        StressTestReport report = BuildReport(
            results,
            options,
            startedAtUtc,
            DateTimeOffset.UtcNow,
            dispatchElapsed,
            totalElapsed,
            activeRequests.Maximum);

        if (reporter is not null)
        {
            await reporter.StopAsync().ConfigureAwait(false);
            WriteFinalReport(report);
        }

        return report;
    }

    private static async Task RunRequestAndStoreAsync(
        HttpClient client,
        SemaphoreSlim concurrency,
        Uri uri,
        byte[]? expectedBytes,
        int siteNumber,
        int requestNumber,
        StressRequestResult[] results,
        int resultIndex,
        StressConsoleReporter? reporter,
        ActiveRequestCounter activeRequests,
        CancellationToken cancellationToken)
    {
        try
        {
            StressRequestResult result = await TestSiteAsync(
                client,
                uri,
                expectedBytes,
                siteNumber,
                requestNumber,
                cancellationToken).ConfigureAwait(false);

            results[resultIndex] = result;
            reporter?.ReportRequestCompleted(result);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The scheduler observes cancellation. Keeping request tasks non-faulted
            // allows completed tasks to be discarded throughout a long run.
        }
        finally
        {
            activeRequests.Decrement();
            concurrency.Release();
        }
    }

    private static async Task<StressRequestResult> TestSiteAsync(
        HttpClient client,
        Uri uri,
        byte[]? expectedBytes,
        int siteNumber,
        int requestNumber,
        CancellationToken cancellationToken)
    {
        DateTimeOffset startedAtUtc = DateTimeOffset.UtcNow;
        long startedTimestamp = Stopwatch.GetTimestamp();
        double headersMilliseconds = 0;
        long contentBytes = 0;
        int statusCode = 0;
        string? redirectedUrl = null;
        ushort protocolVersion = 0;
        bool contentMatched = expectedBytes is null;

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, uri)
            {
                Version = HttpVersion.Version20,
                VersionPolicy = HttpVersionPolicy.RequestVersionOrLower
            };

            using HttpResponseMessage response = await client.SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken).ConfigureAwait(false);

            headersMilliseconds = GetElapsedMilliseconds(startedTimestamp);
            statusCode = (int)response.StatusCode;
            Uri? responseUri = response.RequestMessage?.RequestUri;
            if (responseUri is not null && !uri.Equals(responseUri))
            {
                redirectedUrl = responseUri.AbsoluteUri;
            }

            protocolVersion = PackVersion(response.Version);

            ContentReadResult contentResult = await ReadContentAsync(
                response.Content,
                expectedBytes,
                cancellationToken).ConfigureAwait(false);

            contentBytes = contentResult.ContentBytes;
            contentMatched = contentResult.ExpectedTextFound;

            StressFailureKind failureKind;
            string? error;

            if (!response.IsSuccessStatusCode)
            {
                failureKind = StressFailureKind.HttpStatus;
                error = $"HTTP {(int)response.StatusCode} {response.ReasonPhrase}";
            }
            else if (!contentMatched)
            {
                failureKind = StressFailureKind.ContentMismatch;
                error = "The expected per-site text was not found in the response body.";
            }
            else
            {
                failureKind = StressFailureKind.None;
                error = null;
            }

            return new StressRequestResult(
                requestNumber,
                siteNumber,
                startedAtUtc,
                statusCode,
                failureKind,
                headersMilliseconds,
                GetElapsedMilliseconds(startedTimestamp),
                contentBytes,
                redirectedUrl,
                protocolVersion,
                expectedBytes is not null,
                contentMatched,
                error);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (OperationCanceledException)
        {
            return CreateFailure(StressFailureKind.Timeout, "Request timed out.");
        }
        catch (HttpRequestException exception)
        {
            return CreateFailure(StressFailureKind.Network, exception.Message);
        }
        catch (Exception exception)
        {
            return CreateFailure(StressFailureKind.Other, exception.Message);
        }

        StressRequestResult CreateFailure(StressFailureKind failureKind, string error)
        {
            return new StressRequestResult(
                requestNumber,
                siteNumber,
                startedAtUtc,
                statusCode,
                failureKind,
                headersMilliseconds,
                GetElapsedMilliseconds(startedTimestamp),
                contentBytes,
                redirectedUrl,
                protocolVersion,
                expectedBytes is not null,
                contentMatched,
                error);
        }
    }

    private static async Task<ContentReadResult> ReadContentAsync(
        HttpContent content,
        byte[]? expectedBytes,
        CancellationToken cancellationToken)
    {
        await using Stream stream = await content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        int expectedLength = expectedBytes?.Length ?? 0;
        byte[] buffer = ArrayPool<byte>.Shared.Rent(ContentBufferSize + expectedLength);
        long totalBytes = 0;
        int carryLength = 0;
        bool expectedTextFound = expectedBytes is null;

        try
        {
            while (true)
            {
                int bytesRead = await stream.ReadAsync(
                    buffer.AsMemory(carryLength, ContentBufferSize),
                    cancellationToken).ConfigureAwait(false);

                if (bytesRead == 0)
                {
                    return new ContentReadResult(totalBytes, expectedTextFound);
                }

                totalBytes += bytesRead;
                int availableLength = carryLength + bytesRead;

                if (!expectedTextFound
                    && buffer.AsSpan(0, availableLength).IndexOf(expectedBytes) >= 0)
                {
                    expectedTextFound = true;
                }

                if (!expectedTextFound && expectedLength > 1)
                {
                    carryLength = Math.Min(expectedLength - 1, availableLength);
                    buffer.AsSpan(availableLength - carryLength, carryLength).CopyTo(buffer);
                }
                else
                {
                    carryLength = 0;
                }
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    private static HttpClient CreateHttpClient(StressTestOptions options)
    {
        TimeSpan connectTimeout = options.RequestTimeout < TimeSpan.FromSeconds(10)
            ? options.RequestTimeout
            : TimeSpan.FromSeconds(10);

        var handler = new SocketsHttpHandler
        {
            AllowAutoRedirect = true,
            AutomaticDecompression = DecompressionMethods.All,
            ConnectTimeout = connectTimeout,
            EnableMultipleHttp2Connections = true,
            MaxConnectionsPerServer = options.MaxConcurrency,
            // The test rotates through 5,000 hostnames. Retaining every idle
            // hostname connection for minutes can exhaust the client file limit.
            PooledConnectionIdleTimeout = TimeSpan.FromSeconds(1),
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            UseCookies = false,
            UseProxy = false
        };

        var client = new HttpClient(handler, disposeHandler: true)
        {
            Timeout = options.RequestTimeout
        };

        client.DefaultRequestHeaders.UserAgent.ParseAdd(options.UserAgent);
        return client;
    }

    private static Uri[] CreateSiteUris(StressTestOptions options)
    {
        string[] urls = CreateSiteUrlStrings(options);
        var uris = new Uri[urls.Length];

        for (int index = 0; index < urls.Length; index++)
        {
            uris[index] = new Uri(urls[index], UriKind.Absolute);
        }

        return uris;
    }

    private static string[] CreateSiteUrlStrings(StressTestOptions options)
    {
        int siteCount = options.LastSiteNumber - options.FirstSiteNumber + 1;
        var urls = new string[siteCount];

        for (int index = 0; index < siteCount; index++)
        {
            int siteNumber = options.FirstSiteNumber + index;
            urls[index] = options.UrlTemplate.Replace(
                "{0}",
                siteNumber.ToString(CultureInfo.InvariantCulture),
                StringComparison.Ordinal);
        }

        return urls;
    }

    private static byte[][]? CreateExpectedBytes(StressTestOptions options)
    {
        if (options.ExpectedTextTemplate is null)
        {
            return null;
        }

        int siteCount = options.LastSiteNumber - options.FirstSiteNumber + 1;
        var expectedBytes = new byte[siteCount][];

        for (int index = 0; index < siteCount; index++)
        {
            int siteNumber = options.FirstSiteNumber + index;
            string expectedText = options.ExpectedTextTemplate.Replace(
                "{0}",
                siteNumber.ToString(CultureInfo.InvariantCulture),
                StringComparison.Ordinal);
            expectedBytes[index] = Encoding.UTF8.GetBytes(expectedText);
        }

        return expectedBytes;
    }

    private static ushort PackVersion(Version version)
    {
        int major = Math.Clamp(version.Major, 0, byte.MaxValue);
        int minor = Math.Clamp(version.Minor, 0, byte.MaxValue);
        return (ushort)((major << 8) | minor);
    }

    private static int SelectSiteNumber(StressTestOptions options, int requestIndex)
    {
        int siteCount = options.LastSiteNumber - options.FirstSiteNumber + 1;

        if (options.SelectionMode == SiteSelectionMode.Sequential)
        {
            return options.FirstSiteNumber + (requestIndex % siteCount);
        }

        uint value = unchecked((uint)(requestIndex + options.RandomSeed));
        value ^= value >> 16;
        value *= 0x7FEB352Du;
        value ^= value >> 15;
        value *= 0x846CA68Bu;
        value ^= value >> 16;

        return options.FirstSiteNumber + (int)(value % (uint)siteCount);
    }

    private static StressTestReport BuildReport(
        StressRequestResult[] results,
        StressTestOptions options,
        DateTimeOffset startedAtUtc,
        DateTimeOffset finishedAtUtc,
        TimeSpan dispatchElapsed,
        TimeSpan totalElapsed,
        int maximumActiveCount)
    {
        int successfulCount = 0;
        int timeoutCount = 0;
        int networkFailureCount = 0;
        int httpFailureCount = 0;
        int contentMismatchCount = 0;
        int otherFailureCount = 0;
        long totalContentBytes = 0;
        var touchedSites = new bool[options.LastSiteNumber - options.FirstSiteNumber + 1];

        for (int index = 0; index < results.Length; index++)
        {
            StressRequestResult result = results[index];
            totalContentBytes += result.ContentBytes;
            touchedSites[result.SiteNumber - options.FirstSiteNumber] = true;

            if (result.IsSuccess)
            {
                successfulCount++;
                continue;
            }

            switch (result.FailureKind)
            {
                case StressFailureKind.Timeout:
                    timeoutCount++;
                    break;
                case StressFailureKind.Network:
                    networkFailureCount++;
                    break;
                case StressFailureKind.HttpStatus:
                    httpFailureCount++;
                    break;
                case StressFailureKind.ContentMismatch:
                    contentMismatchCount++;
                    break;
                default:
                    otherFailureCount++;
                    break;
            }
        }

        int uniqueSitesTouched = 0;
        for (int index = 0; index < touchedSites.Length; index++)
        {
            if (touchedSites[index])
            {
                uniqueSitesTouched++;
            }
        }

        double[] headerTimes = new double[successfulCount];
        double[] totalTimes = new double[successfulCount];
        int successIndex = 0;

        for (int index = 0; index < results.Length; index++)
        {
            StressRequestResult result = results[index];
            if (!result.IsSuccess)
            {
                continue;
            }

            headerTimes[successIndex] = result.HeadersMilliseconds;
            totalTimes[successIndex] = result.TotalMilliseconds;
            successIndex++;
        }

        return new StressTestReport(
            results,
            CreateSiteUrlStrings(options),
            options.FirstSiteNumber,
            options.RequestsPerSecond,
            options.Duration,
            options.MaxConcurrency,
            maximumActiveCount,
            uniqueSitesTouched,
            startedAtUtc,
            finishedAtUtc,
            dispatchElapsed,
            totalElapsed,
            successfulCount,
            timeoutCount,
            networkFailureCount,
            httpFailureCount,
            contentMismatchCount,
            otherFailureCount,
            totalContentBytes,
            CreateStatistics(headerTimes),
            CreateStatistics(totalTimes));
    }

    private static SiteSpeedStatistics? CreateStatistics(double[] values)
    {
        if (values.Length == 0)
        {
            return null;
        }

        Array.Sort(values);
        double sum = 0;

        for (int index = 0; index < values.Length; index++)
        {
            sum += values[index];
        }

        return new SiteSpeedStatistics(
            values.Length,
            values[0],
            sum / values.Length,
            GetPercentile(values, 0.50),
            GetPercentile(values, 0.95),
            GetPercentile(values, 0.99),
            values[^1]);
    }

    private static double GetPercentile(double[] sortedValues, double percentile)
    {
        int index = Math.Max(0, (int)Math.Ceiling(percentile * sortedValues.Length) - 1);
        return sortedValues[index];
    }

    private static async ValueTask WaitForStartSlotAsync(
        long targetTimestamp,
        CancellationToken cancellationToken)
    {
        long precisionWindowTicks = Math.Max(1, Stopwatch.Frequency / 4_000);

        while (true)
        {
            long remainingTicks = targetTimestamp - Stopwatch.GetTimestamp();
            if (remainingTicks <= 0)
            {
                return;
            }

            if (remainingTicks > precisionWindowTicks)
            {
                long delayTicks = remainingTicks - precisionWindowTicks;
                await Task.Delay(
                    TimeSpan.FromSeconds((double)delayTicks / Stopwatch.Frequency),
                    cancellationToken).ConfigureAwait(false);
                continue;
            }

            cancellationToken.ThrowIfCancellationRequested();
            Thread.SpinWait(16);
        }
    }

    private static async Task ObserveScheduledTasksAsync(List<Task> tasks)
    {
        for (int index = 0; index < tasks.Count; index++)
        {
            try
            {
                await tasks[index].ConfigureAwait(false);
            }
            catch
            {
                // Observe all scheduled task failures before the original error is rethrown.
            }
        }
    }

    private static double GetElapsedMilliseconds(long startedTimestamp)
    {
        return (Stopwatch.GetTimestamp() - startedTimestamp) * 1000d / Stopwatch.Frequency;
    }

    private static void WriteFinalReport(StressTestReport report)
    {
        Console.WriteLine();
        Console.WriteLine("================ STRESS TEST RESULT ================");
        Console.WriteLine(
            $"Requests: {report.TotalCount:N0} | OK: {report.SuccessfulCount:N0} "
            + $"({report.SuccessPercentage:N2}%) | failed: {report.FailedCount:N0}");
        Console.WriteLine(
            $"Target: {report.TargetRequestsPerSecond:N0} starts/s | "
            + $"actual starts: {report.ActualStartsPerSecond:N2}/s | "
            + $"completed: {report.CompletedRequestsPerSecond:N2}/s");
        Console.WriteLine(
            $"Sites touched: {report.UniqueSitesTouched:N0} | max active requests: "
            + $"{report.MaximumActiveRequests:N0}/{report.ConfiguredMaxConcurrency:N0}");
        Console.WriteLine(
            $"Timeout: {report.TimeoutCount:N0} | network: {report.NetworkFailureCount:N0} | "
            + $"HTTP: {report.HttpFailureCount:N0} | content mismatch: "
            + $"{report.ContentMismatchCount:N0} | other: {report.OtherFailureCount:N0}");
        Console.WriteLine(
            $"Data read: {report.TotalContentBytes / (1024d * 1024d):N2} MiB | "
            + $"elapsed: {report.TotalElapsed:hh\\:mm\\:ss}");

        WriteStatistics("HEADERS", report.SuccessfulHeaderTime);
        WriteStatistics("CONTENT", report.SuccessfulTotalTime);
        Console.WriteLine("====================================================");

        static void WriteStatistics(string name, SiteSpeedStatistics? statistics)
        {
            if (statistics is null)
            {
                Console.WriteLine($"[{name}] No successful measurements.");
                return;
            }

            Console.WriteLine(
                $"[{name}] avg {statistics.AverageMilliseconds:N1} ms | "
                + $"p50 {statistics.P50Milliseconds:N1} ms | "
                + $"p95 {statistics.P95Milliseconds:N1} ms | "
                + $"p99 {statistics.P99Milliseconds:N1} ms | "
                + $"max {statistics.MaximumMilliseconds:N1} ms");
        }
    }

    private static void ValidateOptions(StressTestOptions options)
    {
        if (options.FirstSiteNumber < 1 || options.LastSiteNumber < options.FirstSiteNumber)
        {
            throw new ArgumentOutOfRangeException(nameof(options.FirstSiteNumber));
        }

        if (options.RequestsPerSecond is < 1 or > MaximumRequestsPerSecond)
        {
            throw new ArgumentOutOfRangeException(nameof(options.RequestsPerSecond));
        }

        if (options.Duration <= TimeSpan.Zero
            || options.Duration > MaximumDuration
            || options.RequestTimeout <= TimeSpan.Zero)
        {
            throw new ArgumentOutOfRangeException(nameof(options.Duration));
        }

        if (options.MaxConcurrency is < 1 or > MaximumConcurrency)
        {
            throw new ArgumentOutOfRangeException(nameof(options.MaxConcurrency));
        }

        if (!options.UrlTemplate.Contains("{0}", StringComparison.Ordinal))
        {
            throw new ArgumentException("URL template must contain {0}.", nameof(options.UrlTemplate));
        }

        if (options.ExpectedTextTemplate is not null
            && (!options.ExpectedTextTemplate.Contains("{0}", StringComparison.Ordinal)
                || options.ExpectedTextTemplate.Length > 4096))
        {
            throw new ArgumentException(
                "Expected text must contain {0} and cannot exceed 4,096 characters.",
                nameof(options.ExpectedTextTemplate));
        }
    }

    private readonly struct ContentReadResult
    {
        public ContentReadResult(long contentBytes, bool expectedTextFound)
        {
            ContentBytes = contentBytes;
            ExpectedTextFound = expectedTextFound;
        }

        public long ContentBytes { get; }

        public bool ExpectedTextFound { get; }
    }

    private sealed class ActiveRequestCounter
    {
        private int _current;
        private int _maximum;

        public int Maximum => Volatile.Read(ref _maximum);

        public void Increment()
        {
            int candidate = Interlocked.Increment(ref _current);
            int currentMaximum = Volatile.Read(ref _maximum);

            while (candidate > currentMaximum)
            {
                int observed = Interlocked.CompareExchange(ref _maximum, candidate, currentMaximum);
                if (observed == currentMaximum)
                {
                    return;
                }

                currentMaximum = observed;
            }
        }

        public void Decrement()
        {
            Interlocked.Decrement(ref _current);
        }
    }

    private sealed class StressConsoleReporter
    {
        private readonly int _plannedRequestCount;
        private readonly long _startedTimestamp;
        private readonly PeriodicTimer _timer;
        private readonly Task _statusTask;

        private int _started;
        private int _startedInterval;
        private int _completed;
        private int _completedInterval;
        private int _successful;
        private int _failed;
        private long _intervalMicroseconds;
        private int _isStopped;

        public StressConsoleReporter(StressTestOptions options, int plannedRequestCount)
        {
            _plannedRequestCount = plannedRequestCount;
            _startedTimestamp = Stopwatch.GetTimestamp();
            _timer = new PeriodicTimer(TimeSpan.FromSeconds(1));

            Console.WriteLine(
                $"Starting stress test: {plannedRequestCount:N0} planned requests over "
                + $"{options.Duration}, target {options.RequestsPerSecond:N0}/s, "
                + $"maximum concurrency {options.MaxConcurrency:N0}.");
            Console.WriteLine(
                $"Sites: {options.FirstSiteNumber:N0}-{options.LastSiteNumber:N0}, "
                + $"selection: {options.SelectionMode}, timeout: {options.RequestTimeout}.");
            Console.WriteLine(
                $"Content verification: {(options.ExpectedTextTemplate is null ? "disabled" : "enabled")}.");
            Console.WriteLine();

            _statusTask = RunStatusLoopAsync();
        }

        public void ReportRequestStarted()
        {
            Interlocked.Increment(ref _started);
            Interlocked.Increment(ref _startedInterval);
        }

        public void ReportRequestCompleted(StressRequestResult result)
        {
            long microseconds = (long)(result.TotalMilliseconds * 1000d);
            Interlocked.Increment(ref _completed);
            Interlocked.Increment(ref _completedInterval);
            Interlocked.Add(ref _intervalMicroseconds, microseconds);

            if (result.IsSuccess)
            {
                Interlocked.Increment(ref _successful);
            }
            else
            {
                Interlocked.Increment(ref _failed);
            }
        }

        public async ValueTask StopAsync()
        {
            if (Interlocked.Exchange(ref _isStopped, 1) != 0)
            {
                return;
            }

            _timer.Dispose();
            await _statusTask.ConfigureAwait(false);
            WriteStatus();
        }

        private async Task RunStatusLoopAsync()
        {
            while (await _timer.WaitForNextTickAsync().ConfigureAwait(false))
            {
                WriteStatus();
            }
        }

        private void WriteStatus()
        {
            int startedInterval = Interlocked.Exchange(ref _startedInterval, 0);
            int completedInterval = Interlocked.Exchange(ref _completedInterval, 0);
            long intervalMicroseconds = Interlocked.Exchange(ref _intervalMicroseconds, 0);
            int started = Volatile.Read(ref _started);
            int completed = Volatile.Read(ref _completed);
            int active = started - completed;
            double intervalAverageMilliseconds = completedInterval > 0
                ? intervalMicroseconds / 1000d / completedInterval
                : 0;
            TimeSpan elapsed = Stopwatch.GetElapsedTime(_startedTimestamp);
            double completedRate = elapsed.TotalSeconds > 0 ? completed / elapsed.TotalSeconds : 0;

            Console.WriteLine(
                $"[{elapsed:mm\\:ss}] sent {started:N0}/{_plannedRequestCount:N0} +{startedInterval:N0} | "
                + $"done {completed:N0} +{completedInterval:N0} | active {active:N0} | "
                + $"OK {Volatile.Read(ref _successful):N0} fail {Volatile.Read(ref _failed):N0} | "
                + $"1s {intervalAverageMilliseconds:N0}ms | rate {completedRate:N1}/s");
        }
    }
}

public enum SiteSelectionMode
{
    Sequential,
    Random
}

public enum StressFailureKind
{
    None,
    Timeout,
    Network,
    HttpStatus,
    ContentMismatch,
    Other
}

public sealed class StressTestOptions
{
    public int FirstSiteNumber { get; init; } = 1;

    public int LastSiteNumber { get; init; } = 5000;

    public int RequestsPerSecond { get; init; } = 10;

    public TimeSpan Duration { get; init; } = TimeSpan.FromMinutes(5);

    public TimeSpan RequestTimeout { get; init; } = TimeSpan.FromSeconds(30);

    public int MaxConcurrency { get; init; } = 200;

    public string UrlTemplate { get; init; } = "https://site{0}.trykooboo.com/";

    public string? ExpectedTextTemplate { get; init; }

    public SiteSelectionMode SelectionMode { get; init; } = SiteSelectionMode.Sequential;

    public int RandomSeed { get; init; } = 1942;

    public string UserAgent { get; init; } = "Kooboo-Site-Stress-Test/1.0";

    public bool WriteProgressToConsole { get; init; } = true;
}

public readonly struct StressRequestResult
{
    public StressRequestResult(
        int requestNumber,
        int siteNumber,
        DateTimeOffset startedAtUtc,
        int statusCode,
        StressFailureKind failureKind,
        double headersMilliseconds,
        double totalMilliseconds,
        long contentBytes,
        string? redirectedUrl,
        ushort protocolVersion,
        bool wasContentChecked,
        bool contentMatched,
        string? error)
    {
        RequestNumber = requestNumber;
        SiteNumber = siteNumber;
        StartedAtUtc = startedAtUtc;
        RawStatusCode = statusCode;
        FailureKind = failureKind;
        HeadersMilliseconds = headersMilliseconds;
        TotalMilliseconds = totalMilliseconds;
        ContentBytes = contentBytes;
        RedirectedUrl = redirectedUrl;
        PackedProtocolVersion = protocolVersion;
        WasContentChecked = wasContentChecked;
        ContentMatched = contentMatched;
        Error = error;
    }

    public int RequestNumber { get; }
    public int SiteNumber { get; }
    public DateTimeOffset StartedAtUtc { get; }
    public int RawStatusCode { get; }
    public int? StatusCode => RawStatusCode == 0 ? null : RawStatusCode;
    public bool IsSuccess => FailureKind == StressFailureKind.None;
    public StressFailureKind FailureKind { get; }
    public double HeadersMilliseconds { get; }
    public double TotalMilliseconds { get; }
    public long ContentBytes { get; }
    public string? RedirectedUrl { get; }
    public ushort PackedProtocolVersion { get; }
    public string? ProtocolVersion => PackedProtocolVersion == 0
        ? null
        : string.Create(
            CultureInfo.InvariantCulture,
            $"{PackedProtocolVersion >> 8}.{PackedProtocolVersion & byte.MaxValue}");
    public bool WasContentChecked { get; }
    public bool ContentMatched { get; }
    public string? Error { get; }
}

public sealed class StressTestReport
{
    public StressTestReport(
        StressRequestResult[] results,
        string[] siteUrls,
        int firstSiteNumber,
        int targetRequestsPerSecond,
        TimeSpan requestedDuration,
        int configuredMaxConcurrency,
        int maximumActiveRequests,
        int uniqueSitesTouched,
        DateTimeOffset startedAtUtc,
        DateTimeOffset finishedAtUtc,
        TimeSpan dispatchElapsed,
        TimeSpan totalElapsed,
        int successfulCount,
        int timeoutCount,
        int networkFailureCount,
        int httpFailureCount,
        int contentMismatchCount,
        int otherFailureCount,
        long totalContentBytes,
        SiteSpeedStatistics? successfulHeaderTime,
        SiteSpeedStatistics? successfulTotalTime)
    {
        Results = results;
        SiteUrls = siteUrls;
        FirstSiteNumber = firstSiteNumber;
        TargetRequestsPerSecond = targetRequestsPerSecond;
        RequestedDuration = requestedDuration;
        ConfiguredMaxConcurrency = configuredMaxConcurrency;
        MaximumActiveRequests = maximumActiveRequests;
        UniqueSitesTouched = uniqueSitesTouched;
        StartedAtUtc = startedAtUtc;
        FinishedAtUtc = finishedAtUtc;
        DispatchElapsed = dispatchElapsed;
        TotalElapsed = totalElapsed;
        SuccessfulCount = successfulCount;
        TimeoutCount = timeoutCount;
        NetworkFailureCount = networkFailureCount;
        HttpFailureCount = httpFailureCount;
        ContentMismatchCount = contentMismatchCount;
        OtherFailureCount = otherFailureCount;
        TotalContentBytes = totalContentBytes;
        SuccessfulHeaderTime = successfulHeaderTime;
        SuccessfulTotalTime = successfulTotalTime;
    }

    public StressRequestResult[] Results { get; }
    public string[] SiteUrls { get; }
    public int FirstSiteNumber { get; }
    public int TargetRequestsPerSecond { get; }
    public TimeSpan RequestedDuration { get; }
    public int ConfiguredMaxConcurrency { get; }
    public int MaximumActiveRequests { get; }
    public int UniqueSitesTouched { get; }
    public DateTimeOffset StartedAtUtc { get; }
    public DateTimeOffset FinishedAtUtc { get; }
    public TimeSpan DispatchElapsed { get; }
    public TimeSpan TotalElapsed { get; }
    public int TotalCount => Results.Length;
    public int SuccessfulCount { get; }
    public int FailedCount => TotalCount - SuccessfulCount;
    public double SuccessPercentage => TotalCount > 0 ? SuccessfulCount * 100d / TotalCount : 0;
    public int TimeoutCount { get; }
    public int NetworkFailureCount { get; }
    public int HttpFailureCount { get; }
    public int ContentMismatchCount { get; }
    public int OtherFailureCount { get; }
    public long TotalContentBytes { get; }
    public double ActualStartsPerSecond => DispatchElapsed.TotalSeconds > 0
        ? TotalCount / (DispatchElapsed.TotalSeconds + (1d / TargetRequestsPerSecond))
        : 0;
    public double CompletedRequestsPerSecond => TotalElapsed.TotalSeconds > 0
        ? TotalCount / TotalElapsed.TotalSeconds
        : 0;
    public SiteSpeedStatistics? SuccessfulHeaderTime { get; }
    public SiteSpeedStatistics? SuccessfulTotalTime { get; }

    public string GetSiteUrl(int siteNumber)
    {
        return SiteUrls[siteNumber - FirstSiteNumber];
    }
}
