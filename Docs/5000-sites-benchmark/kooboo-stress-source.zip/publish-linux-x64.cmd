@echo off
setlocal

dotnet publish "%~dp0Kooboo.SiteStressTest.csproj" ^
  -c Release ^
  -r linux-x64 ^
  --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:PublishTrimmed=true ^
  -p:DebugType=None ^
  -p:DebugSymbols=false ^
  -o "%~dp0publish\linux-x64"

if errorlevel 1 exit /b %errorlevel%

if exist "%~dp0publish\linux-x64\kooboo-site-stress" del /q "%~dp0publish\linux-x64\kooboo-site-stress"

echo.
echo Linux application created in:
echo %~dp0publish\linux-x64
