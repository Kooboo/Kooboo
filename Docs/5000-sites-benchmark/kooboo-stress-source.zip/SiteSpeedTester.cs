using System.Buffers;
using System.Diagnostics;
using System.Globalization;
using System.Net;

namespace Kooboo.SiteStressTest;

/// <summary>
/// Measures the cold-visit speed of numbered trykooboo.com sites.
/// Request starts are evenly spaced so that slow sites do not delay later start slots.
/// </summary>
public static class SiteSpeedTester
{
    private const int ContentBufferSize = 16 * 1024;

    /// <summary>
    /// Tests https://site1.trykooboo.com/ through https://site5000.trykooboo.com/
    /// at six new requests per second.
    /// </summary>
    public static Task<SiteSpeedTestReport> TestTryKoobooSitesAsync(
        CancellationToken cancellationToken = default)
    {
        return TestAsync(new SiteSpeedTestOptions(), cancellationToken);
    }

    /// <summary>
    /// Runs a configurable site-speed test. The response body is fully downloaded and
    /// counted, but is not retained in memory.
    /// </summary>
    public static async Task<SiteSpeedTestReport> TestAsync(
        SiteSpeedTestOptions options,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(options);
        ValidateOptions(options);

        int siteCount = checked(options.LastSiteNumber - options.FirstSiteNumber + 1);
        var tasks = new Task<SiteSpeedResult>[siteCount];

        using var client = CreateHttpClient(options);

        ConsoleProgressReporter? progressReporter = options.WriteProgressToConsole
            ? new ConsoleProgressReporter(options, siteCount)
            : null;

        DateTimeOffset startedAtUtc = DateTimeOffset.UtcNow;
        long testStartedTimestamp = Stopwatch.GetTimestamp();
        long startIntervalTicks = Math.Max(1, Stopwatch.Frequency / options.RequestsPerSecond);
        long nextStartTimestamp = testStartedTimestamp;
        int scheduledCount = 0;

        try
        {
            for (int index = 0; index < siteCount; index++)
            {
                await WaitForStartSlotAsync(nextStartTimestamp, cancellationToken).ConfigureAwait(false);

                long actualStartTimestamp = Stopwatch.GetTimestamp();
                int siteNumber = options.FirstSiteNumber + index;
                progressReporter?.ReportRequestStarted();
                tasks[index] = TestSiteAndReportAsync(
                    client,
                    siteNumber,
                    attemptNumber: 1,
                    options.UrlTemplate,
                    options.ExpectedTextTemplate,
                    progressReporter,
                    cancellationToken);
                scheduledCount++;
                long scheduledNextTimestamp = nextStartTimestamp + startIntervalTicks;
                nextStartTimestamp = scheduledNextTimestamp > actualStartTimestamp
                    ? scheduledNextTimestamp
                    : actualStartTimestamp + startIntervalTicks;
            }
        }
        catch
        {
            client.CancelPendingRequests();
            await ObserveScheduledTasksAsync(tasks, scheduledCount).ConfigureAwait(false);
            if (progressReporter is not null)
            {
                await progressReporter.StopAsync().ConfigureAwait(false);
            }

            throw;
        }

        TimeSpan dispatchElapsed = Stopwatch.GetElapsedTime(testStartedTimestamp);
        SiteSpeedResult[] initialResults;

        try
        {
            initialResults = await Task.WhenAll(tasks).ConfigureAwait(false);
        }
        catch
        {
            client.CancelPendingRequests();
            if (progressReporter is not null)
            {
                await progressReporter.StopAsync().ConfigureAwait(false);
            }

            throw;
        }

        SiteSpeedResult[] results = (SiteSpeedResult[])initialResults.Clone();
        var attempts = new List<SiteSpeedResult>(siteCount);
        attempts.AddRange(initialResults);

        for (int retryNumber = 1; retryNumber <= options.MaxRetryAttempts; retryNumber++)
        {
            int failedCount = CountFailures(results);
            if (failedCount == 0)
            {
                break;
            }

            progressReporter?.ReportRetryRoundStarted(
                retryNumber,
                options.MaxRetryAttempts,
                failedCount,
                options.RetryDelay);

            if (options.RetryDelay > TimeSpan.Zero)
            {
                try
                {
                    await Task.Delay(options.RetryDelay, cancellationToken).ConfigureAwait(false);
                }
                catch
                {
                    client.CancelPendingRequests();
                    if (progressReporter is not null)
                    {
                        await progressReporter.StopAsync().ConfigureAwait(false);
                    }

                    throw;
                }
            }

            int[] resultIndexes = new int[failedCount];
            var retryTasks = new Task<SiteSpeedResult>[failedCount];
            long nextRetryStartTimestamp = Stopwatch.GetTimestamp();
            int retryScheduledCount = 0;

            try
            {
                for (int resultIndex = 0; resultIndex < results.Length; resultIndex++)
                {
                    if (results[resultIndex].IsSuccess)
                    {
                        continue;
                    }

                    await WaitForStartSlotAsync(
                        nextRetryStartTimestamp,
                        cancellationToken).ConfigureAwait(false);

                    long actualStartTimestamp = Stopwatch.GetTimestamp();
                    resultIndexes[retryScheduledCount] = resultIndex;
                    progressReporter?.ReportRequestStarted();
                    retryTasks[retryScheduledCount] = TestSiteAndReportAsync(
                        client,
                        results[resultIndex].SiteNumber,
                        retryNumber + 1,
                        options.UrlTemplate,
                        options.ExpectedTextTemplate,
                        progressReporter,
                        cancellationToken);
                    retryScheduledCount++;
                    long scheduledNextTimestamp = nextRetryStartTimestamp + startIntervalTicks;
                    nextRetryStartTimestamp = scheduledNextTimestamp > actualStartTimestamp
                        ? scheduledNextTimestamp
                        : actualStartTimestamp + startIntervalTicks;
                }
            }
            catch
            {
                client.CancelPendingRequests();
                await ObserveScheduledTasksAsync(retryTasks, retryScheduledCount).ConfigureAwait(false);
                if (progressReporter is not null)
                {
                    await progressReporter.StopAsync().ConfigureAwait(false);
                }

                throw;
            }

            SiteSpeedResult[] retryResults;

            try
            {
                retryResults = await Task.WhenAll(retryTasks).ConfigureAwait(false);
            }
            catch
            {
                client.CancelPendingRequests();
                if (progressReporter is not null)
                {
                    await progressReporter.StopAsync().ConfigureAwait(false);
                }

                throw;
            }

            attempts.AddRange(retryResults);

            for (int index = 0; index < retryResults.Length; index++)
            {
                results[resultIndexes[index]] = retryResults[index];
            }
        }

        TimeSpan totalElapsed = Stopwatch.GetElapsedTime(testStartedTimestamp);

        SiteSpeedTestReport report = BuildReport(
            initialResults,
            results,
            attempts.ToArray(),
            options.RequestsPerSecond,
            startedAtUtc,
            DateTimeOffset.UtcNow,
            dispatchElapsed,
            totalElapsed);

        if (progressReporter is not null)
        {
            await progressReporter.StopAsync().ConfigureAwait(false);
            WriteFinalReport(report, options.MaxFailuresInFinalOverview);
        }

        return report;
    }

    private static HttpClient CreateHttpClient(SiteSpeedTestOptions options)
    {
        TimeSpan connectTimeout = options.RequestTimeout < TimeSpan.FromSeconds(10)
            ? options.RequestTimeout
            : TimeSpan.FromSeconds(10);

        var handler = new SocketsHttpHandler
        {
            AllowAutoRedirect = true,
            AutomaticDecompression = DecompressionMethods.All,
            ConnectTimeout = connectTimeout,
            PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            UseCookies = false
        };

        var client = new HttpClient(handler, disposeHandler: true)
        {
            Timeout = options.RequestTimeout
        };

        client.DefaultRequestHeaders.UserAgent.ParseAdd(options.UserAgent);
        return client;
    }

    private static async Task<SiteSpeedResult> TestSiteAsync(
        HttpClient client,
        int siteNumber,
        int attemptNumber,
        string urlTemplate,
        string? expectedTextTemplate,
        CancellationToken cancellationToken)
    {
        string siteNumberText = siteNumber.ToString(CultureInfo.InvariantCulture);
        string url = urlTemplate.Replace(
            "{0}",
            siteNumberText,
            StringComparison.Ordinal);
        byte[]? expectedBytes = expectedTextTemplate is null
            ? null
            : System.Text.Encoding.UTF8.GetBytes(
                expectedTextTemplate.Replace("{0}", siteNumberText, StringComparison.Ordinal));

        DateTimeOffset startedAtUtc = DateTimeOffset.UtcNow;
        long startedTimestamp = Stopwatch.GetTimestamp();
        double headersMilliseconds = 0;
        long contentBytes = 0;
        int? statusCode = null;
        string? finalUrl = null;
        string? protocolVersion = null;
        string? contentType = null;
        bool contentMatched = expectedBytes is null;

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, url)
            {
                Version = HttpVersion.Version20,
                VersionPolicy = HttpVersionPolicy.RequestVersionOrLower
            };

            using HttpResponseMessage response = await client.SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken).ConfigureAwait(false);

            headersMilliseconds = GetElapsedMilliseconds(startedTimestamp);
            statusCode = (int)response.StatusCode;
            finalUrl = response.RequestMessage?.RequestUri?.AbsoluteUri;
            protocolVersion = response.Version.ToString();
            contentType = response.Content.Headers.ContentType?.MediaType;

            SiteContentReadResult contentResult = await ReadContentAsync(
                response.Content,
                expectedBytes,
                cancellationToken).ConfigureAwait(false);
            contentBytes = contentResult.ContentBytes;
            contentMatched = contentResult.ExpectedTextFound;

            bool isSuccess = response.IsSuccessStatusCode && contentMatched;
            string? error = response.IsSuccessStatusCode && !contentMatched
                ? "The expected per-site text was not found in the response body."
                : null;

            return new SiteSpeedResult(
                siteNumber,
                attemptNumber,
                url,
                finalUrl,
                startedAtUtc,
                statusCode,
                isSuccess,
                headersMilliseconds,
                GetElapsedMilliseconds(startedTimestamp),
                contentBytes,
                protocolVersion,
                contentType,
                error,
                wasContentChecked: expectedBytes is not null,
                contentMatched);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (OperationCanceledException)
        {
            return CreateFailureResult("Request timed out.");
        }
        catch (Exception exception)
        {
            return CreateFailureResult(exception.Message);
        }

        SiteSpeedResult CreateFailureResult(string error)
        {
            return new SiteSpeedResult(
                siteNumber,
                attemptNumber,
                url,
                finalUrl,
                startedAtUtc,
                statusCode,
                isSuccess: false,
                headersMilliseconds,
                GetElapsedMilliseconds(startedTimestamp),
                contentBytes,
                protocolVersion,
                contentType,
                error,
                wasContentChecked: expectedBytes is not null,
                contentMatched);
        }
    }

    private static async Task<SiteSpeedResult> TestSiteAndReportAsync(
        HttpClient client,
        int siteNumber,
        int attemptNumber,
        string urlTemplate,
        string? expectedTextTemplate,
        ConsoleProgressReporter? progressReporter,
        CancellationToken cancellationToken)
    {
        SiteSpeedResult result = await TestSiteAsync(
            client,
            siteNumber,
            attemptNumber,
            urlTemplate,
            expectedTextTemplate,
            cancellationToken).ConfigureAwait(false);

        progressReporter?.ReportRequestCompleted(result);
        return result;
    }

    private static async Task<SiteContentReadResult> ReadContentAsync(
        HttpContent content,
        byte[]? expectedBytes,
        CancellationToken cancellationToken)
    {
        await using Stream stream = await content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        int expectedLength = expectedBytes?.Length ?? 0;
        byte[] buffer = ArrayPool<byte>.Shared.Rent(ContentBufferSize + expectedLength);
        long totalBytes = 0;
        int carryLength = 0;
        bool expectedTextFound = expectedBytes is null;

        try
        {
            while (true)
            {
                int bytesRead = await stream.ReadAsync(
                    buffer.AsMemory(carryLength, ContentBufferSize),
                    cancellationToken).ConfigureAwait(false);

                if (bytesRead == 0)
                {
                    return new SiteContentReadResult(totalBytes, expectedTextFound);
                }

                totalBytes += bytesRead;
                int availableLength = carryLength + bytesRead;

                if (!expectedTextFound
                    && buffer.AsSpan(0, availableLength).IndexOf(expectedBytes) >= 0)
                {
                    expectedTextFound = true;
                }

                if (!expectedTextFound && expectedLength > 1)
                {
                    carryLength = Math.Min(expectedLength - 1, availableLength);
                    buffer.AsSpan(availableLength - carryLength, carryLength).CopyTo(buffer);
                }
                else
                {
                    carryLength = 0;
                }
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    private static async ValueTask WaitForStartSlotAsync(
        long targetTimestamp,
        CancellationToken cancellationToken)
    {
        long precisionWindowTicks = Math.Max(1, Stopwatch.Frequency / 4_000);

        while (true)
        {
            long remainingTicks = targetTimestamp - Stopwatch.GetTimestamp();
            if (remainingTicks <= 0)
            {
                return;
            }

            if (remainingTicks > precisionWindowTicks)
            {
                long delayTicks = remainingTicks - precisionWindowTicks;
                await Task.Delay(
                    TimeSpan.FromSeconds((double)delayTicks / Stopwatch.Frequency),
                    cancellationToken).ConfigureAwait(false);
                continue;
            }

            cancellationToken.ThrowIfCancellationRequested();
            Thread.SpinWait(16);
        }
    }

    private static async Task ObserveScheduledTasksAsync(
        Task<SiteSpeedResult>[] tasks,
        int scheduledCount)
    {
        for (int index = 0; index < scheduledCount; index++)
        {
            try
            {
                await tasks[index].ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                // Expected when the caller cancels the complete test.
            }
            catch
            {
                // Observe any task failure before rethrowing the scheduling failure.
            }
        }
    }

    private static SiteSpeedTestReport BuildReport(
        SiteSpeedResult[] initialResults,
        SiteSpeedResult[] results,
        SiteSpeedResult[] attempts,
        int requestedStartsPerSecond,
        DateTimeOffset startedAtUtc,
        DateTimeOffset finishedAtUtc,
        TimeSpan dispatchElapsed,
        TimeSpan totalElapsed)
    {
        int successfulCount = 0;

        for (int index = 0; index < results.Length; index++)
        {
            SiteSpeedResult result = results[index];
            if (result.IsSuccess)
            {
                successfulCount++;
            }
        }

        long totalContentBytes = 0;
        for (int index = 0; index < attempts.Length; index++)
        {
            totalContentBytes += attempts[index].ContentBytes;
        }

        double[] successfulHeaderTimes = new double[successfulCount];
        double[] successfulTotalTimes = new double[successfulCount];
        int successIndex = 0;

        for (int index = 0; index < results.Length; index++)
        {
            SiteSpeedResult result = results[index];
            if (!result.IsSuccess)
            {
                continue;
            }

            successfulHeaderTimes[successIndex] = result.HeadersMilliseconds;
            successfulTotalTimes[successIndex] = result.TotalMilliseconds;
            successIndex++;
        }

        return new SiteSpeedTestReport(
            results,
            attempts,
            requestedStartsPerSecond,
            startedAtUtc,
            finishedAtUtc,
            dispatchElapsed,
            totalElapsed,
            CountSuccesses(initialResults),
            successfulCount,
            totalContentBytes,
            CreateStatistics(successfulHeaderTimes),
            CreateStatistics(successfulTotalTimes));
    }

    private static SiteSpeedStatistics? CreateStatistics(double[] values)
    {
        if (values.Length == 0)
        {
            return null;
        }

        Array.Sort(values);
        double sum = 0;

        for (int index = 0; index < values.Length; index++)
        {
            sum += values[index];
        }

        return new SiteSpeedStatistics(
            values.Length,
            values[0],
            sum / values.Length,
            GetNearestRankPercentile(values, 0.50),
            GetNearestRankPercentile(values, 0.95),
            GetNearestRankPercentile(values, 0.99),
            values[^1]);
    }

    private static double GetNearestRankPercentile(double[] sortedValues, double percentile)
    {
        int index = Math.Max(0, (int)Math.Ceiling(percentile * sortedValues.Length) - 1);
        return sortedValues[index];
    }

    private static double GetElapsedMilliseconds(long startedTimestamp)
    {
        return (Stopwatch.GetTimestamp() - startedTimestamp) * 1000d / Stopwatch.Frequency;
    }

    private static int CountFailures(SiteSpeedResult[] results)
    {
        return results.Length - CountSuccesses(results);
    }

    private static int CountSuccesses(SiteSpeedResult[] results)
    {
        int successfulCount = 0;

        for (int index = 0; index < results.Length; index++)
        {
            if (results[index].IsSuccess)
            {
                successfulCount++;
            }
        }

        return successfulCount;
    }

    private static void WriteFinalReport(
        SiteSpeedTestReport report,
        int maxFailuresInOverview)
    {
        Console.WriteLine();
        Console.WriteLine("================ FINAL OVERVIEW ================");
        Console.WriteLine($"Sites tested:       {report.TotalCount:N0}");
        Console.WriteLine(
            $"Initial pass:       {report.InitialSuccessfulCount:N0} successful, "
            + $"{report.InitialFailedCount:N0} failed");
        Console.WriteLine(
            $"Retries:            {report.RetryAttemptCount:N0} attempts, "
            + $"{report.RecoveredByRetryCount:N0} sites recovered");
        Console.WriteLine(
            $"Final result:       {report.SuccessfulCount:N0} successful, "
            + $"{report.FailedCount:N0} failed "
            + $"({report.SuccessPercentage:N2}% successful)");
        Console.WriteLine(
            $"Traffic:            {report.TotalAttemptCount:N0} HTTP attempts, "
            + $"{report.TotalContentBytes / (1024d * 1024d):N2} MiB read");
        Console.WriteLine(
            $"Timing:             dispatch {report.DispatchElapsed:hh\\:mm\\:ss}, "
            + $"total {report.TotalElapsed:hh\\:mm\\:ss}, "
            + $"{report.CompletedAttemptsPerSecond:N2} attempts/second");

        WriteStatistics("HEADERS", report.SuccessfulHeaderTime);
        WriteStatistics("CONTENT", report.SuccessfulTotalTime);

        if (report.FailedCount > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Still failing after retries:");

            int displayedCount = 0;
            for (int index = 0; index < report.Results.Length; index++)
            {
                SiteSpeedResult result = report.Results[index];
                if (result.IsSuccess)
                {
                    continue;
                }

                if (displayedCount >= maxFailuresInOverview)
                {
                    break;
                }

                string statusCode = result.StatusCode?.ToString(CultureInfo.InvariantCulture) ?? "---";
                string error = string.IsNullOrWhiteSpace(result.Error)
                    ? "HTTP request was not successful."
                    : ConsoleProgressReporter.GetSingleLineError(result.Error);

                Console.WriteLine(
                    $"  site{result.SiteNumber}: HTTP {statusCode}, "
                    + $"attempts {result.AttemptNumber}, {error}");
                displayedCount++;
            }

            int omittedCount = report.FailedCount - displayedCount;
            if (omittedCount > 0)
            {
                Console.WriteLine($"  ... {omittedCount:N0} more failures not displayed.");
            }
        }

        Console.WriteLine("================================================");

        static void WriteStatistics(string name, SiteSpeedStatistics? statistics)
        {
            if (statistics is null)
            {
                Console.WriteLine($"[{name}] No successful measurements.");
                return;
            }

            Console.WriteLine(
                $"[{name}] average {statistics.AverageMilliseconds:N1} ms | "
                + $"p50 {statistics.P50Milliseconds:N1} ms | "
                + $"p95 {statistics.P95Milliseconds:N1} ms | "
                + $"p99 {statistics.P99Milliseconds:N1} ms | "
                + $"maximum {statistics.MaximumMilliseconds:N1} ms");
        }
    }

    private static void ValidateOptions(SiteSpeedTestOptions options)
    {
        if (options.FirstSiteNumber < 1)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.FirstSiteNumber),
                "The first site number must be at least 1.");
        }

        if (options.LastSiteNumber < options.FirstSiteNumber)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.LastSiteNumber),
                "The last site number must be greater than or equal to the first site number.");
        }

        if (options.RequestsPerSecond < 1)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.RequestsPerSecond),
                "Requests per second must be at least 1.");
        }

        if (options.RequestTimeout <= TimeSpan.Zero
            || options.RequestTimeout == Timeout.InfiniteTimeSpan)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.RequestTimeout),
                "The request timeout must be a positive, finite duration.");
        }

        if (string.IsNullOrWhiteSpace(options.UserAgent))
        {
            throw new ArgumentException("The user agent cannot be empty.", nameof(options.UserAgent));
        }

        if (string.IsNullOrWhiteSpace(options.UrlTemplate)
            || !options.UrlTemplate.Contains("{0}", StringComparison.Ordinal))
        {
            throw new ArgumentException(
                "The URL template must contain the {0} site-number placeholder.",
                nameof(options.UrlTemplate));
        }

        if (options.ExpectedTextTemplate is not null
            && (!options.ExpectedTextTemplate.Contains("{0}", StringComparison.Ordinal)
                || options.ExpectedTextTemplate.Length > 4096))
        {
            throw new ArgumentException(
                "Expected text must contain {0} and cannot exceed 4,096 characters.",
                nameof(options.ExpectedTextTemplate));
        }

        if (options.ProgressInterval <= TimeSpan.Zero
            || options.ProgressInterval == Timeout.InfiniteTimeSpan)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.ProgressInterval),
                "The progress interval must be a positive, finite duration.");
        }

        if (options.MaxRetryAttempts < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.MaxRetryAttempts),
                "The maximum retry attempts cannot be negative.");
        }

        if (options.RetryDelay < TimeSpan.Zero
            || options.RetryDelay == Timeout.InfiniteTimeSpan)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.RetryDelay),
                "The retry delay must be a non-negative, finite duration.");
        }

        if (options.MaxFailuresInFinalOverview < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(options.MaxFailuresInFinalOverview),
                "The maximum number of displayed failures cannot be negative.");
        }
    }

    private sealed class ConsoleProgressReporter
    {
        private readonly object _consoleLock = new();
        private readonly int _totalCount;
        private readonly long _startedTimestamp;
        private readonly PeriodicTimer _timer;
        private readonly Task _statusTask;

        private int _startedCount;
        private int _startedSinceLastStatus;
        private int _completedCount;
        private int _completedSinceLastStatus;
        private int _successfulCount;
        private int _failedCount;
        private long _contentBytes;
        private double _completedMilliseconds;
        private double _completedMillisecondsSinceLastStatus;
        private double _lastMilliseconds;
        private int _isStopped;

        public ConsoleProgressReporter(SiteSpeedTestOptions options, int totalCount)
        {
            _totalCount = totalCount;
            _startedTimestamp = Stopwatch.GetTimestamp();
            _timer = new PeriodicTimer(options.ProgressInterval);

            Console.WriteLine(
                $"Starting site speed test: site{options.FirstSiteNumber} through "
                + $"site{options.LastSiteNumber}, {options.RequestsPerSecond} request starts/second, "
                + $"{options.RequestTimeout.TotalSeconds:N0}-second timeout.");
            Console.WriteLine(
                $"Failed sites receive up to {options.MaxRetryAttempts} additional attempt(s). "
                + "[DONE] reports a fully downloaded response. [STATUS] is the live summary.");
            Console.WriteLine();

            _statusTask = RunStatusLoopAsync();
        }

        public void ReportRequestStarted()
        {
            lock (_consoleLock)
            {
                _startedCount++;
                _startedSinceLastStatus++;
            }
        }

        public void ReportRequestCompleted(SiteSpeedResult result)
        {
            lock (_consoleLock)
            {
                _completedCount++;
                _completedSinceLastStatus++;
                _contentBytes += result.ContentBytes;
                _completedMilliseconds += result.TotalMilliseconds;
                _completedMillisecondsSinceLastStatus += result.TotalMilliseconds;
                _lastMilliseconds = result.TotalMilliseconds;

                if (result.IsSuccess)
                {
                    _successfulCount++;
                }
                else
                {
                    _failedCount++;
                }

                string outcome = result.IsSuccess ? "OK  " : "FAIL";
                string statusCode = result.StatusCode?.ToString(CultureInfo.InvariantCulture) ?? "---";
                string protocol = result.ProtocolVersion ?? "-";

                Console.WriteLine(
                    $"[DONE {_completedCount,5}] {outcome} site{result.SiteNumber,-4} "
                    + $"try {result.AttemptNumber} | "
                    + $"HTTP {statusCode,-3} | headers {result.HeadersMilliseconds,8:N1} ms | "
                    + $"total {result.TotalMilliseconds,8:N1} ms | "
                    + $"{result.ContentBytes / 1024d,8:N1} KiB | {protocol}");

                if (!result.IsSuccess && !string.IsNullOrWhiteSpace(result.Error))
                {
                    Console.WriteLine($"                         Error: {GetSingleLineError(result.Error)}");
                }
            }
        }

        public void ReportRetryRoundStarted(
            int retryNumber,
            int maximumRetryCount,
            int failedSiteCount,
            TimeSpan retryDelay)
        {
            lock (_consoleLock)
            {
                Console.WriteLine();
                Console.WriteLine(
                    $"[RETRY {retryNumber}/{maximumRetryCount}] Retrying {failedSiteCount:N0} failed site(s) "
                    + $"after {retryDelay.TotalSeconds:N1} seconds.");
            }
        }

        public async ValueTask StopAsync()
        {
            if (Interlocked.Exchange(ref _isStopped, 1) != 0)
            {
                return;
            }

            _timer.Dispose();
            await _statusTask.ConfigureAwait(false);
            WriteStatus();
        }

        private async Task RunStatusLoopAsync()
        {
            while (await _timer.WaitForNextTickAsync().ConfigureAwait(false))
            {
                WriteStatus();
            }
        }

        private void WriteStatus()
        {
            lock (_consoleLock)
            {
                TimeSpan elapsed = Stopwatch.GetElapsedTime(_startedTimestamp);
                int activeCount = _startedCount - _completedCount;
                double intervalAverage = _completedSinceLastStatus > 0
                    ? _completedMillisecondsSinceLastStatus / _completedSinceLastStatus
                    : 0;
                double overallAverage = _completedCount > 0
                    ? _completedMilliseconds / _completedCount
                    : 0;

                Console.WriteLine(
                    $"[STATUS {elapsed:hh\\:mm\\:ss}] sites {_totalCount,4} | "
                    + $"attempts started {_startedCount,5} (+{_startedSinceLastStatus}) | "
                    + $"completed {_completedCount,5} "
                    + $"(+{_completedSinceLastStatus}) | active {activeCount,3} | "
                    + $"attempt OK {_successfulCount,4} | fail {_failedCount,3} | "
                    + $"last {_lastMilliseconds,8:N1} ms | "
                    + $"1-sec avg {intervalAverage,8:N1} ms | all avg {overallAverage,8:N1} ms | "
                    + $"{_contentBytes / (1024d * 1024d),8:N2} MiB");

                _startedSinceLastStatus = 0;
                _completedSinceLastStatus = 0;
                _completedMillisecondsSinceLastStatus = 0;
            }
        }

        public static string GetSingleLineError(string error)
        {
            string singleLine = error.Replace('\r', ' ').Replace('\n', ' ');
            const int maximumLength = 200;

            return singleLine.Length <= maximumLength
                ? singleLine
                : string.Concat(singleLine.AsSpan(0, maximumLength), "...");
        }
    }

    private readonly struct SiteContentReadResult
    {
        public SiteContentReadResult(long contentBytes, bool expectedTextFound)
        {
            ContentBytes = contentBytes;
            ExpectedTextFound = expectedTextFound;
        }

        public long ContentBytes { get; }

        public bool ExpectedTextFound { get; }
    }
}

public sealed class SiteSpeedTestOptions
{
    public int FirstSiteNumber { get; init; } = 1;

    public int LastSiteNumber { get; init; } = 5000;

    public int RequestsPerSecond { get; init; } = 10;

    public TimeSpan RequestTimeout { get; init; } = TimeSpan.FromSeconds(30);

    public string UrlTemplate { get; init; } = "https://site{0}.trykooboo.com/";

    public string? ExpectedTextTemplate { get; init; }

    public string UserAgent { get; init; } = "Kooboo-Site-Speed-Test/1.0";

    public bool WriteProgressToConsole { get; init; } = true;

    public TimeSpan ProgressInterval { get; init; } = TimeSpan.FromSeconds(1);

    /// <summary>
    /// Number of additional attempts made for sites whose latest attempt failed.
    /// </summary>
    public int MaxRetryAttempts { get; init; } = 1;

    /// <summary>
    /// Pause before each retry round. Retry requests still use RequestsPerSecond pacing.
    /// </summary>
    public TimeSpan RetryDelay { get; init; } = TimeSpan.FromSeconds(2);

    /// <summary>
    /// Maximum number of final failures printed in the console overview.
    /// </summary>
    public int MaxFailuresInFinalOverview { get; init; } = 50;
}

public sealed class SiteSpeedResult
{
    public SiteSpeedResult(
        int siteNumber,
        string url,
        string? finalUrl,
        DateTimeOffset startedAtUtc,
        int? statusCode,
        bool isSuccess,
        double headersMilliseconds,
        double totalMilliseconds,
        long contentBytes,
        string? protocolVersion,
        string? contentType,
        string? error,
        bool wasContentChecked = false,
        bool contentMatched = true)
        : this(
            siteNumber,
            attemptNumber: 1,
            url,
            finalUrl,
            startedAtUtc,
            statusCode,
            isSuccess,
            headersMilliseconds,
            totalMilliseconds,
            contentBytes,
            protocolVersion,
            contentType,
            error,
            wasContentChecked,
            contentMatched)
    {
    }

    public SiteSpeedResult(
        int siteNumber,
        int attemptNumber,
        string url,
        string? finalUrl,
        DateTimeOffset startedAtUtc,
        int? statusCode,
        bool isSuccess,
        double headersMilliseconds,
        double totalMilliseconds,
        long contentBytes,
        string? protocolVersion,
        string? contentType,
        string? error,
        bool wasContentChecked = false,
        bool contentMatched = true)
    {
        SiteNumber = siteNumber;
        AttemptNumber = attemptNumber;
        Url = url;
        FinalUrl = finalUrl;
        StartedAtUtc = startedAtUtc;
        StatusCode = statusCode;
        IsSuccess = isSuccess;
        HeadersMilliseconds = headersMilliseconds;
        TotalMilliseconds = totalMilliseconds;
        ContentBytes = contentBytes;
        ProtocolVersion = protocolVersion;
        ContentType = contentType;
        Error = error;
        WasContentChecked = wasContentChecked;
        ContentMatched = contentMatched;
    }

    public int SiteNumber { get; }

    public int AttemptNumber { get; }

    public string Url { get; }

    public string? FinalUrl { get; }

    public DateTimeOffset StartedAtUtc { get; }

    public int? StatusCode { get; }

    public bool IsSuccess { get; }

    /// <summary>
    /// Time until all response headers arrive. This includes DNS, connection, TLS and redirects.
    /// </summary>
    public double HeadersMilliseconds { get; }

    /// <summary>
    /// Time until the complete response body has been downloaded.
    /// </summary>
    public double TotalMilliseconds { get; }

    /// <summary>
    /// Number of decompressed response-body bytes read by HttpClient.
    /// </summary>
    public long ContentBytes { get; }

    public string? ProtocolVersion { get; }

    public string? ContentType { get; }

    public string? Error { get; }

    public bool WasContentChecked { get; }

    public bool ContentMatched { get; }
}

public sealed class SiteSpeedTestReport
{
    public SiteSpeedTestReport(
        SiteSpeedResult[] results,
        int requestedStartsPerSecond,
        DateTimeOffset startedAtUtc,
        DateTimeOffset finishedAtUtc,
        TimeSpan dispatchElapsed,
        TimeSpan totalElapsed,
        int successfulCount,
        long totalContentBytes,
        SiteSpeedStatistics? successfulHeaderTime,
        SiteSpeedStatistics? successfulTotalTime)
        : this(
            results,
            results,
            requestedStartsPerSecond,
            startedAtUtc,
            finishedAtUtc,
            dispatchElapsed,
            totalElapsed,
            successfulCount,
            successfulCount,
            totalContentBytes,
            successfulHeaderTime,
            successfulTotalTime)
    {
    }

    public SiteSpeedTestReport(
        SiteSpeedResult[] results,
        SiteSpeedResult[] attempts,
        int requestedStartsPerSecond,
        DateTimeOffset startedAtUtc,
        DateTimeOffset finishedAtUtc,
        TimeSpan dispatchElapsed,
        TimeSpan totalElapsed,
        int initialSuccessfulCount,
        int successfulCount,
        long totalContentBytes,
        SiteSpeedStatistics? successfulHeaderTime,
        SiteSpeedStatistics? successfulTotalTime)
    {
        Results = results;
        Attempts = attempts;
        RequestedStartsPerSecond = requestedStartsPerSecond;
        StartedAtUtc = startedAtUtc;
        FinishedAtUtc = finishedAtUtc;
        DispatchElapsed = dispatchElapsed;
        TotalElapsed = totalElapsed;
        InitialSuccessfulCount = initialSuccessfulCount;
        SuccessfulCount = successfulCount;
        TotalContentBytes = totalContentBytes;
        SuccessfulHeaderTime = successfulHeaderTime;
        SuccessfulTotalTime = successfulTotalTime;
    }

    public SiteSpeedResult[] Results { get; }

    public SiteSpeedResult[] Attempts { get; }

    public int RequestedStartsPerSecond { get; }

    public DateTimeOffset StartedAtUtc { get; }

    public DateTimeOffset FinishedAtUtc { get; }

    public TimeSpan DispatchElapsed { get; }

    public TimeSpan TotalElapsed { get; }

    public int TotalCount => Results.Length;

    public int SuccessfulCount { get; }

    public int FailedCount => TotalCount - SuccessfulCount;

    public int InitialSuccessfulCount { get; }

    public int InitialFailedCount => TotalCount - InitialSuccessfulCount;

    public int TotalAttemptCount => Attempts.Length;

    public int RetryAttemptCount => TotalAttemptCount - TotalCount;

    public int RecoveredByRetryCount => SuccessfulCount - InitialSuccessfulCount;

    public double SuccessPercentage => TotalCount > 0
        ? SuccessfulCount * 100d / TotalCount
        : 0;

    public long TotalContentBytes { get; }

    public double CompletedRequestsPerSecond => TotalElapsed.TotalSeconds > 0
        ? TotalCount / TotalElapsed.TotalSeconds
        : 0;

    public double CompletedAttemptsPerSecond => TotalElapsed.TotalSeconds > 0
        ? TotalAttemptCount / TotalElapsed.TotalSeconds
        : 0;

    public SiteSpeedStatistics? SuccessfulHeaderTime { get; }

    public SiteSpeedStatistics? SuccessfulTotalTime { get; }
}

public sealed class SiteSpeedStatistics
{
    public SiteSpeedStatistics(
        int count,
        double minimumMilliseconds,
        double averageMilliseconds,
        double p50Milliseconds,
        double p95Milliseconds,
        double p99Milliseconds,
        double maximumMilliseconds)
    {
        Count = count;
        MinimumMilliseconds = minimumMilliseconds;
        AverageMilliseconds = averageMilliseconds;
        P50Milliseconds = p50Milliseconds;
        P95Milliseconds = p95Milliseconds;
        P99Milliseconds = p99Milliseconds;
        MaximumMilliseconds = maximumMilliseconds;
    }

    public int Count { get; }

    public double MinimumMilliseconds { get; }

    public double AverageMilliseconds { get; }

    public double P50Milliseconds { get; }

    public double P95Milliseconds { get; }

    public double P99Milliseconds { get; }

    public double MaximumMilliseconds { get; }
}
