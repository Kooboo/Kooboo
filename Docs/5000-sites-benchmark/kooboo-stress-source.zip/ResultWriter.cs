using System.Globalization;
using System.Text;

namespace Kooboo.SiteStressTest;

public static class ResultWriter
{
    public static async Task WriteSweepAsync(
        SiteSpeedTestReport report,
        string outputDirectory,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(report);
        Directory.CreateDirectory(outputDirectory);

        string csvPath = Path.Combine(outputDirectory, "sweep-requests.csv");
        await using (var writer = new StreamWriter(csvPath, append: false, new UTF8Encoding(false)))
        {
            await writer.WriteLineAsync(
                "site_number,attempt,started_utc,url,final_url,status,success,headers_ms,total_ms,content_bytes,protocol,content_type,content_checked,content_matched,error");

            for (int index = 0; index < report.Attempts.Length; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                SiteSpeedResult result = report.Attempts[index];
                await writer.WriteLineAsync(string.Join(',',
                    result.SiteNumber.ToString(CultureInfo.InvariantCulture),
                    result.AttemptNumber.ToString(CultureInfo.InvariantCulture),
                    Csv(result.StartedAtUtc.ToString("O", CultureInfo.InvariantCulture)),
                    Csv(result.Url),
                    Csv(result.FinalUrl),
                    result.StatusCode?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                    result.IsSuccess ? "true" : "false",
                    result.HeadersMilliseconds.ToString("F3", CultureInfo.InvariantCulture),
                    result.TotalMilliseconds.ToString("F3", CultureInfo.InvariantCulture),
                    result.ContentBytes.ToString(CultureInfo.InvariantCulture),
                    Csv(result.ProtocolVersion),
                    Csv(result.ContentType),
                    result.WasContentChecked ? "true" : "false",
                    result.ContentMatched ? "true" : "false",
                    Csv(result.Error))).ConfigureAwait(false);
            }
        }

        var summary = new StringBuilder(1024);
        summary.AppendLine("Kooboo site sweep result");
        summary.AppendLine($"Started UTC: {report.StartedAtUtc:O}");
        summary.AppendLine($"Finished UTC: {report.FinishedAtUtc:O}");
        summary.AppendLine($"Sites: {report.TotalCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Successful: {report.SuccessfulCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Failed: {report.FailedCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Recovered by retry: {report.RecoveredByRetryCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Attempts: {report.TotalAttemptCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Elapsed: {report.TotalElapsed}");
        AppendStatistics(summary, "Headers", report.SuccessfulHeaderTime);
        AppendStatistics(summary, "Complete content", report.SuccessfulTotalTime);

        await File.WriteAllTextAsync(
            Path.Combine(outputDirectory, "summary.txt"),
            summary.ToString(),
            new UTF8Encoding(false),
            cancellationToken).ConfigureAwait(false);
    }

    public static async Task WriteStressAsync(
        StressTestReport report,
        string outputDirectory,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(report);
        Directory.CreateDirectory(outputDirectory);

        string csvPath = Path.Combine(outputDirectory, "stress-requests.csv");
        await using (var writer = new StreamWriter(csvPath, append: false, new UTF8Encoding(false)))
        {
            await writer.WriteLineAsync(
                "request_number,site_number,started_utc,url,final_url,status,success,failure_kind,headers_ms,total_ms,content_bytes,protocol,content_checked,content_matched,error");

            for (int index = 0; index < report.Results.Length; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                StressRequestResult result = report.Results[index];
                string url = report.GetSiteUrl(result.SiteNumber);
                await writer.WriteLineAsync(string.Join(',',
                    result.RequestNumber.ToString(CultureInfo.InvariantCulture),
                    result.SiteNumber.ToString(CultureInfo.InvariantCulture),
                    Csv(result.StartedAtUtc.ToString("O", CultureInfo.InvariantCulture)),
                    Csv(url),
                    Csv(result.RedirectedUrl ?? url),
                    result.StatusCode?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                    result.IsSuccess ? "true" : "false",
                    result.FailureKind.ToString(),
                    result.HeadersMilliseconds.ToString("F3", CultureInfo.InvariantCulture),
                    result.TotalMilliseconds.ToString("F3", CultureInfo.InvariantCulture),
                    result.ContentBytes.ToString(CultureInfo.InvariantCulture),
                    Csv(result.ProtocolVersion),
                    result.WasContentChecked ? "true" : "false",
                    result.ContentMatched ? "true" : "false",
                    Csv(result.Error))).ConfigureAwait(false);
            }
        }

        var summary = new StringBuilder(1400);
        summary.AppendLine("Kooboo site stress-test result");
        summary.AppendLine($"Started UTC: {report.StartedAtUtc:O}");
        summary.AppendLine($"Finished UTC: {report.FinishedAtUtc:O}");
        summary.AppendLine($"Requested duration: {report.RequestedDuration}");
        summary.AppendLine($"Total elapsed: {report.TotalElapsed}");
        summary.AppendLine($"Requests: {report.TotalCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Successful: {report.SuccessfulCount.ToString("N0", CultureInfo.InvariantCulture)} ({report.SuccessPercentage.ToString("F2", CultureInfo.InvariantCulture)}%)");
        summary.AppendLine($"Failed: {report.FailedCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Target starts/second: {report.TargetRequestsPerSecond.ToString(CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Actual starts/second: {report.ActualStartsPerSecond.ToString("F2", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Completed requests/second: {report.CompletedRequestsPerSecond.ToString("F2", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Unique sites touched: {report.UniqueSitesTouched.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Maximum active requests: {report.MaximumActiveRequests.ToString("N0", CultureInfo.InvariantCulture)} / {report.ConfiguredMaxConcurrency.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Timeout failures: {report.TimeoutCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Network failures: {report.NetworkFailureCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"HTTP failures: {report.HttpFailureCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Content mismatches: {report.ContentMismatchCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Other failures: {report.OtherFailureCount.ToString("N0", CultureInfo.InvariantCulture)}");
        summary.AppendLine($"Content bytes: {report.TotalContentBytes.ToString("N0", CultureInfo.InvariantCulture)}");
        AppendStatistics(summary, "Headers", report.SuccessfulHeaderTime);
        AppendStatistics(summary, "Complete content", report.SuccessfulTotalTime);

        await File.WriteAllTextAsync(
            Path.Combine(outputDirectory, "summary.txt"),
            summary.ToString(),
            new UTF8Encoding(false),
            cancellationToken).ConfigureAwait(false);
    }

    private static void AppendStatistics(
        StringBuilder builder,
        string name,
        SiteSpeedStatistics? statistics)
    {
        if (statistics is null)
        {
            builder.AppendLine($"{name}: no successful measurements");
            return;
        }

        builder.Append(name);
        builder.Append(": min ");
        builder.Append(statistics.MinimumMilliseconds.ToString("F3", CultureInfo.InvariantCulture));
        builder.Append(" ms, average ");
        builder.Append(statistics.AverageMilliseconds.ToString("F3", CultureInfo.InvariantCulture));
        builder.Append(" ms, p50 ");
        builder.Append(statistics.P50Milliseconds.ToString("F3", CultureInfo.InvariantCulture));
        builder.Append(" ms, p95 ");
        builder.Append(statistics.P95Milliseconds.ToString("F3", CultureInfo.InvariantCulture));
        builder.Append(" ms, p99 ");
        builder.Append(statistics.P99Milliseconds.ToString("F3", CultureInfo.InvariantCulture));
        builder.Append(" ms, max ");
        builder.Append(statistics.MaximumMilliseconds.ToString("F3", CultureInfo.InvariantCulture));
        builder.AppendLine(" ms");
    }

    private static string Csv(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }

        bool mustQuote = value.Contains(',')
            || value.Contains('"')
            || value.Contains('\r')
            || value.Contains('\n');

        if (!mustQuote)
        {
            return value;
        }

        return string.Concat('"', value.Replace("\"", "\"\"", StringComparison.Ordinal), '"');
    }
}
