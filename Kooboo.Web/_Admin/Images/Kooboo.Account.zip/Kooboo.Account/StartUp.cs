﻿using Kooboo.Data.Server;
using System.Collections.Generic;
using Kooboo.Api;
using System.Configuration;
using System;

namespace Kooboo.Account
{
    public class StartUp
    {
        public static void Main()
        {
            AppDomain.CurrentDomain.UnhandledException += (sender, args) =>
            { 
                Kooboo.Data.Log.Instance.Exception.Write("Unhandled exception: " + args.ExceptionObject.ToString());  
            };
  
            Kooboo.Lib.Compatible.CompatibleManager.Instance.Framework.RegisterEncoding();

            int port = 80;
            string strport = ConfigurationManager.AppSettings.Get("port");
            if (!string.IsNullOrWhiteSpace(strport))
            {
                int tempport;
                if (int.TryParse(strport, out tempport))
                {
                    port = tempport;
                }
            }

            Kooboo.Data.Hosts.WindowsHost.change = new Data.Hosts.HostChange() { NoChange = true }; 
            Kooboo.Data.AppSettings.IsOnlineServer = true;

            Kooboo.Data.AppSettings.SetCustomSslCheck();
              
            List<IKoobooMiddleWare> middlewares = new List<IKoobooMiddleWare>();
             
            middlewares.Add(GetAccountMiddleWare());

            Kooboo.Data.SSL.SslService.AddSslMiddleWare(middlewares);  
            // 443 must start.
            var SecureServer = Kooboo.Data.Server.WebServerFactory.Create(443, middlewares); 
            SecureServer.Start(); 
             
            if (port != 443)
            {
                var server = WebServerFactory.Create(port, middlewares); 
                server.Start(); 
            }

            Console.WriteLine("Account server started at " + port.ToString());

            Kooboo.Lib.Compatible.CompatibleManager.Instance.Framework.ConsoleWait();
        }
          
        public static ApiMiddleware GetAccountMiddleWare()
        {
            var apiprovider = new ApiProvider();
            apiprovider.ApiPrefix = "/account";

            apiprovider.List.Clear();

            var interfaceType = typeof(Kooboo.Api.IApi);

            var assembley = typeof(Kooboo.Account.Api.UserApi).Assembly; // only to get the assembly. 

            foreach (var type in assembley.GetTypes())
            {
                if (!type.IsAbstract && !type.IsInterface && !type.IsGenericType && interfaceType.IsAssignableFrom(type))
                {
                    apiprovider.Set(type);
                }
            }

            var middleware = new ApiMiddleware(apiprovider);
            return middleware; 
        }
    }
}
