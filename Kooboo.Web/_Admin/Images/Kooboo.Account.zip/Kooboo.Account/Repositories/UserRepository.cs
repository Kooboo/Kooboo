﻿using System;
using System.Collections.Generic;
using System.Text;
using Kooboo.Data.Models;

namespace Kooboo.Account.Repositories
{
    public class UserRepository
    {
        //Data is stored in memory, you can save the data in a file or database, or get it remotely
        public static List<User> Users = new List<User>();

        private UserOrganizationRepository userOrganization;

        private OrganizationRepository organization;
        public UserRepository()
        {
            userOrganization = new UserOrganizationRepository();
            organization = new OrganizationRepository();
        }
        public User Get(Guid id)
        {
            return Users.Find(u=>u.Id==id);
        }

        public User GetByEmail(string email)
        {
            return Users.Find(u => u.EmailAddress.Equals(email));
        }

        public User Validate(string username ,string password)
        {
            return Users.Find(u => u.UserName.Equals(username) && u.Password == password);
        }

        public bool Register(string userName,string email,string password,string clientIp,string language)
        {
            var user = new User
            {
                Id = Helper.IDHelper.GetOrHashId(userName),
                UserName = userName,
                EmailAddress = email,
                Password = password,
                Language = language,
                RegisterIp = clientIp
            };
            user.CurrentOrgId = user.Id;
            user.CurrentOrgName = user.UserName;
            Users.Add(user);

            userOrganization.AddUser(user.Id, user.CurrentOrgId);

            organization.Add(user.Id, userName);
            return true;
        }

        public User ChangeOrg(Guid userid,Guid orgId)
        {
            var user = Users.Find(u => u.Id == userid);
            if (user != null)
                user.CurrentOrgId = orgId;

            return user;

        }
        public List<Organization> ListByUser(Guid id)
        {
            var userOrgs = userOrganization.ListByUser(id);
            var orgs = new List<Organization>();
            foreach(var userOrg in userOrgs)
            {
                var org = organization.Get(userOrg.OrganizationId);
                if (org == null) continue;

                orgs.Add(org);
            }

            return orgs;
        }
    }
}
