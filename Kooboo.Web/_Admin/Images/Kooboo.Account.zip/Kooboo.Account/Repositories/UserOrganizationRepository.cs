﻿using System;
using System.Collections.Generic;
using Kooboo.Data.Models;
using System.Linq;

namespace Kooboo.Account.Repositories
{
    public class UserOrganizationRepository
    {
        //Data is stored in memory, you can save the data in a file or database, or get it remotely
        public static List<UserOrganization> UserOrganizations = new List<UserOrganization>();

        public void AddUser(Guid userId,Guid OrgId)
        {
            UserOrganizations.Add(new UserOrganization
            {
                UserId=userId,
                OrganizationId=OrgId
            });
        }

        public List<UserOrganization> ListByUser(Guid userId)
        {
            return UserOrganizations.FindAll(o => o.UserId == userId);
        }

        public List<User> ListUser(Guid organizationId)
        {
            var userIds = UserOrganizations.FindAll(o => o.OrganizationId == organizationId).Select(o=>o.UserId).ToList();

            var users = UserRepository.Users.FindAll(u => userIds.Contains(u.Id));

            return users;
        }

        public void DeleteUser(Guid userId,Guid organizationId)
        {
            var userorg = UserOrganizations.Find(o => o.UserId == userId && o.OrganizationId == organizationId);
            UserOrganizations.Remove(userorg);
        }

    }
}
