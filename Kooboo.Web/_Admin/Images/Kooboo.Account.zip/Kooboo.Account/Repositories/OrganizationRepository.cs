﻿using System;
using System.Collections.Generic;
using Kooboo.Data.Models;

namespace Kooboo.Account.Repositories
{
    public class OrganizationRepository
    {
        //Data is stored in memory, you can save the data in a file or database, or get it remotely
        private static List<Organization> Organizations = new List<Organization>();
        public OrganizationRepository()
        {

        }

        public Organization Get(Guid id)
        {
            return Organizations.Find(o => o.Id== id);
        }

        public Organization Add(Guid id,string name)
        {
            var org = new Organization
            {
                Id = id,
                AdminUser=id,
                Name = name
            };
            Organizations.Add(org);

            return org;
        }

        public Organization GetByUser(Guid userid)
        {
            return Organizations.Find(o => o.AdminUser == userid);
        }

    }
}
