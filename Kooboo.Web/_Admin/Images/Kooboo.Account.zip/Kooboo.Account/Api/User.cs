﻿using Kooboo.Api;
using Kooboo.Data.Helper;
using Kooboo.Data.Models;
using System;
using System.Collections.Generic;
using Kooboo.Account.Repositories;

namespace Kooboo.Account.Api
{
    public class UserApi : IApi
    {
        private UserRepository User = new UserRepository();
        public string ModelName
        {
            get
            {
                return "user";
            }
        }

        public bool RequireSite
        {
            get
            {
                return false;
            }
        }

        public bool RequireUser
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// get user by userid
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public User Get(string id)
        {
            // id can be RSA encrypted. 
            var userid = Helper.IDHelper.GetGuidKey(id);
            var user = User.Get(userid);
            if (user != null)
            {
                user.Password = null;
                user.PasswordHash = default(Guid);
                return user;
            }
            return null;
        }
        /// <summary>
        /// get user by email
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public User GetByEmail(string email)
        {
            var user = User.GetByEmail(email);
            if (user != null)
            {
                user.Password = null;
                user.PasswordHash = default(Guid);
                return user;
            }
            return null;
        }
        /// <summary>
        /// get user profile 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public User Profile(Guid Id)
        {
            var user = User.Get(Id);
            if (user != null)
            {
                user.Password = null;
                return user;
            }
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public User Validate(string UserName, string password)
        {
            var user = User.Validate(UserName, password);
            return user;
        }

        /// <summary>
        /// change user organization
        /// </summary>
        /// <param name="organizationId"></param>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public User ChangeOrg(Guid organizationId, Guid UserId)
        {
            var user = User.ChangeOrg(UserId, organizationId);
            return user;
        }

        /// <summary>
        /// get user's organizations
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="call"></param>
        /// <returns></returns>
        public List<Organization> Organizations(string userId, ApiCall call)
        {    // userid can be rsa encrypted.
            Guid guiduserId = Helper.IDHelper.GetGuidKey(userId);
            return User.ListByUser(guiduserId);
        }

        /// <summary>
        /// register a user
        /// </summary>
        /// <param name="user"></param>
        /// <param name="call"></param>
        /// <returns></returns>
        public bool Register(User user, ApiCall call)
        {
            if (string.IsNullOrEmpty(user.UserName) || string.IsNullOrWhiteSpace(user.Password) || string.IsNullOrWhiteSpace(user.EmailAddress))
            {
                throw new Exception("invalid registration information");
            }
            user.UserName = Lib.Helper.StringHelper.ToValidUserNames(user.UserName);

            string clientip = user.RegisterIp;
            if (string.IsNullOrEmpty(clientip))
            {
                clientip = call.Context.Request.IP;
            }

            return User.Register(user.UserName, user.EmailAddress, user.Password, clientip, user.Language);
        }

        /// <summary>
        /// Check if username is unique
        /// </summary>
        /// <param name="apiCall"></param>
        /// <returns></returns>
        public bool IsUniqueName(ApiCall apiCall)
        {
            string name = apiCall.GetValue("name", "username");
            if (string.IsNullOrEmpty(name))
            {
                return false;
            }
            var userid = Helper.IDHelper.GetOrHashId(name);
            var user = User.Get(userid);
            if (user != null)
            {
                return false;
            }

            return true;
        }

        // this is the update method...  
        public bool Post(User user, ApiCall call)
        {
            return false;
        }

        public bool changePassword(string username, string oldpassword, string newpassword, ApiCall call)
        {
            return false;
        }


        public User changePassword2(string username, string oldpassword, string newpassword, ApiCall call)
        {
            return null;
        }


        public string GetToken(string username, string password, ApiCall call)
        {
            return string.Empty;
        }

        public User GetByToken(ApiCall call)
        {
            return null;
        }

        public Guid ForgotPasswordToken(string email, ApiCall call)
        {
            return Guid.Empty;
        }

        public bool ResetPassword(Guid Token, string newpasspord, ApiCall call)
        {
            return false;
        }


        public bool VerifyEmail(Guid UserId)
        {
            return false;
        }

    }
}
