﻿using Kooboo.Api;
using Kooboo.Data.Models;
using System;
using System.Collections.Generic;
using Kooboo.Account.Repositories;

namespace Kooboo.Account.Api
{
    public class OrganizationApi : IApi
    {
        UserRepository user = new UserRepository();
        UserOrganizationRepository userOrganization = new UserOrganizationRepository();
        OrganizationRepository organization = new OrganizationRepository();
        public string ModelName
        {
            get
            {
                return "organization";
            }
        }

        public bool RequireSite
        {
            get
            {
                return false;
            }
        }


        public bool RequireUser
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// get organination's users
        /// </summary>
        /// <param name="organizationId"></param>
        /// <param name="call"></param>
        /// <returns></returns>
        public List<Data.Models.User> Users(Guid organizationId, ApiCall call)
        {
            return userOrganization.ListUser(organizationId);
        }
      
        /// <summary>
        /// add user to organization
        /// </summary>
        /// <param name="OrganizationId"></param>
        /// <param name="UserName"></param>
        /// <param name="call"></param>
        public void AddUser(Guid OrganizationId, string UserName, ApiCall call)
        {  
            Guid userId = Lib.Security.Hash.ComputeGuidIgnoreCase(UserName);
            userOrganization.AddUser(userId, OrganizationId);
        }
        /// <summary>
        /// delete user from organization
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="organizationId"></param>
        /// <returns></returns>
        public bool DeleteUser(string userName,Guid organizationId)
        {
            Guid userId = Lib.Security.Hash.ComputeGuidIgnoreCase(userName);

            if (user.Get(userId) != null && organization.Get(organizationId) != null)
            {
                userOrganization.DeleteUser(userId, organizationId);
            }
            return true;
        }
        /// <summary>
        /// get organization
        /// </summary>
        /// <param name="id"></param>
        /// <param name="call"></param>
        /// <returns></returns>
        public Organization Get(Guid id, ApiCall call)
        {
            return organization.Get(id);
        }
        /// <summary>
        /// get organization by user
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public Organization GetByUser(Guid UserId)
        {
            return organization.GetByUser(UserId);
        }

        [Attributes.RequireModel(typeof(Organization))]
        public bool Update(ApiCall call)
        {
            return false;
        }
        


    }
}
