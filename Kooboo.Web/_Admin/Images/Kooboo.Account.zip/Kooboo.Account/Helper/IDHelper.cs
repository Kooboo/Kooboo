﻿using Kooboo.Data.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kooboo.Account.Helper
{
 public static  class IDHelper
    {
        public static Guid GetOrHashId(string input)
        { 
            if (string.IsNullOrEmpty(input))
            {
                return default(Guid); 
            } 
            Guid id;  
            if (Guid.TryParse(input, out id))
            {
                return id; 
            } 
            else
            {
                return Lib.Security.Hash.ComputeGuidIgnoreCase(input); 
            } 
        }


        public static Guid GetGuidKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return default(Guid);
            }
            if (key.Length >= RSAHelper.MinEncryptedLenth)
            {
                key = RSAHelper.Decrypt(key);
                return GetGuidKey(key);
            }        
            return GetOrHashId(key);   
        } 
    }
}
